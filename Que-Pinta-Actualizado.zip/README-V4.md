# Que Pinta 4.0.0

Incremental update on the delivered v3 app, preserving its Supabase project and Android app ID `uy.quepinta.app`. The original v3 directory is unchanged. The distribution remains suitable for the user's ZIP-based GitHub Actions workflow and single-file GitHub Pages uploads.

## Behavior

- Compact discovery: city/location shortcut, Todos / Hoy / Este fin de semana, other search/category/availability/mode controls in a filter dialog. Compact cards retain activity, title, time, place, price, seats and detail link.
- Creation chooses presencial/online first. Physical location is grouped in a collapsible section prefilled from browsing; online never requires or stores country, city, coordinates or currency. Optional PC/console/mobile and server region apply only to online games. Access links and handles can be shared in the existing private group chat rather than a new public field.
- Physical currency is assigned from a country map, without a currency selector. Default is free; the price field appears only when Tiene costo is checked. Online plans have no participation cost in this version. Amounts are informational, no payments or conversion. Unknown/no-tender territories cannot enable paid plans.
- Online events bypass country/city filters and use the viewer's device timezone for display and date filters. Their creation uses the creator's device timezone; the instant is stored as timestamptz. Physical times retain the chosen location's timezone.
- Map remains Leaflet + OpenStreetMap tiles and Photon search. The redesign softens the map colors, restyles marker/controls, adds expansion, place confirmation and collapsible map selection. It is not Google Maps or a new geocoding provider. Attribution remains visible and no tile prefetch/background location is added. Search and map tiles require internet.
- Started plans leave public discovery but remain in My plans > Active indefinitely. No end time, estimated duration or automatic finish. Only the owner can finish after the start time. Finished plans move to My plans > Planes anteriores. Existing past plans remain active until their owners finish them.
- A finished plan's member list and group chat remain available. Ordinary member removal and plan deletion are refused after finish to preserve the history. The owner can submit or edit one 1–3 experience rating and optional comment; only the group's owner/members can read it. No rating of people, attendance score or public reputation is created.
- From a past plan's participant profile, send a friend request. Only users sharing a finished plan may send; only the recipient may accept. Requests and friendships are visible solely to their two endpoints. Either can remove the relationship. Friend list lives in Profile > Amigos y solicitudes. This update does not add individual DMs, push notifications, invitations, blocking or reporting.

## Backend and authorization

Run `supabase/ACTUALIZAR-V4.sql` once on the already-activated v3 database. It is transactional and designed to be rerunnable. It relaxes physical location columns only for online plans and retains pairwise coordinate constraints. New tables have RLS, explicit grants and no anonymous access. New trigger functions use SECURITY INVOKER and empty search_path, and their direct EXECUTE privileges are revoked. No service key is added to the client.

`qp_finished_at` is server-timestamped on the owner's explicit update. A dedicated owner update policy allows this operation even if the original project did not grant ordinary plan editing; its check requires finishing. The trigger rejects ownership/ID transfers, premature finishing, simultaneous unrelated field edits and later edits/deletion of a finished plan. Lifecycle and membership writes use the same per-plan transaction advisory lock. New joins are also checked on the server against start time and capacity.

`qp_plan_reviews`: one row per plan; only its owner writes, only its group reads. Finish and optional review are separate requests; a failed review does not undo a successful finish. The UI reports this and supports retrying/editing the review from history.

`qp_friendships`: unique unordered sender/receiver pair; status defaults pending. Explicit column grants and an invoker trigger protect endpoints. RLS requires the recipient to accept, enforces sharing a finished plan on creation, and isolates read/delete to endpoints. Rejected/deleted requests can be sent again; blocking is not implemented.

The v3 age declaration remains self-declared and private. Adult checks and prior chat/profile policies are preserved. This does not implement identity verification.

Do not reapply the old v3 installer to a live v4 database: its old physical-location constraint is incompatible with new online events. The CI job uses v3 only to initialize a fresh disposable fixture before applying v4 twice.

## Validation and limits

Locally passed 18 core/static checks and 9 application-flow checks using a fake DOM and API, including online payloads/cross-country discovery, automatic currency, an active six-hour meetup, manual finish/history/review, recipient acceptance, age and social-link privacy. The tests do not constitute browser, live API or real RLS verification.

`checks-v4.sql` runs in CI following the existing v3 database tests. It tests v4 idempotence, legacy preservation, online insertion, premature/non-owner finish rejection, history retention, owner-only reviews, private review visibility, shared-plan-only requests, reverse-pair deduplication, recipient acceptance and third-party isolation. The CI job must pass before applying SQL to production. Real PostgreSQL, a browser binary, Android SDK and a JDK were unavailable in this local environment; installation was blocked by environment restrictions. Therefore v4 native compilation, SQL execution and phone/map visual testing remain pending in GitHub/on device.

Native target versionCode 40000 / versionName 4.0.0. Existing pinned Capacitor7 and Leaflet1.9.4 dependencies retained. No new native dependencies. Debug APKs built on different ephemeral runners may have different signing certificates and fail to update over the old APK. This delivery contains no release keystore and does not promise in-place upgrades. Generated package-lock artifact should be retained for subsequent reproducible builds.

## Reference material

- [PostgreSQL RLS](https://www.postgresql.org/docs/current/ddl-rowsecurity.html): policy combination and owner/member authorization.
- [Supabase changelog](https://supabase.com/changelog): checked for relevant API exposure changes; new tables have explicit grants.
- [Leaflet reference](https://leafletjs.com/reference.html): zoom controls and invalidateSize for expanded maps.
- [OSM tile policy](https://operations.osmfoundation.org/policies/tiles/): visible attribution and ordinary interactive use.
- Currency map generated from local ICU74 territory data; [ICU currency formatting](https://unicode-org.github.io/icu/userguide/format_parse/numbers/legacy-numberformat.html). It chooses one territory currency, with no exchange rates. Update this snapshot when legal currencies change. Updated Bulgaria to EUR according to the [ECB](https://www.ecb.europa.eu/euro/changeover/bulgaria/html/index.en.html), and Curaçao/Sint Maarten to XCG according to the [CBCS](https://www.centralbank.cw/functions/banknotes-coins/caribbean-guilder/frequently-asked-questions). Multi-currency territories still use a single default in this simplified interface.
