/* Shared, dependency-free rules used by the web app and its checks. */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.PintaCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const ZONE = 'America/Montevideo';
  const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const normalize = value => String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  function participants(plan) { return plan.pinta_participants || []; }
  function owns(plan, user) { return !!user && plan.owner_id === user.id; }
  function attends(plan, user) { return owns(plan, user) || !!user && participants(plan).some(m => m.user_id === user.id); }
  function freeSeats(plan) { return Math.max(0, Number(plan.capacity) - 1 - participants(plan).length); }
  function nextSeat(plan) {
    const used = new Set(participants(plan).map(m => Number(m.seat)));
    for (let seat = 2; seat <= Number(plan.capacity); seat++) if (!used.has(seat)) return seat;
    return null;
  }
  function dateKey(date) {
    const parts = new Intl.DateTimeFormat('en-CA', {timeZone:ZONE,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(date));
    return ['year','month','day'].map(type => parts.find(p => p.type === type).value).join('-');
  }
  function dateWindow(filter, now = new Date()) {
    const start = new Date(dateKey(now) + 'T00:00:00-03:00');
    const day = 86400000;
    if (filter === 'today') return [now.toISOString(), new Date(+start+day).toISOString()];
    if (filter === 'tomorrow') return [new Date(+start+day).toISOString(), new Date(+start+2*day).toISOString()];
    if (filter === 'weekend') {
      const weekday = new Date(dateKey(now)+'T12:00:00Z').getUTCDay();
      const untilSaturday = weekday === 0 ? -1 : (6-weekday+7)%7;
      const saturday = +start + untilSaturday*day;
      return [new Date(Math.max(+now,saturday)).toISOString(), new Date(saturday+2*day).toISOString()];
    }
    return [now.toISOString(), null];
  }
  function inputToISO(value) {
    if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value)) throw Error('Elegí un día y una hora válidos.');
    const date = new Date(value+':00-03:00');
    if (!Number.isFinite(+date) || dateKey(date) !== value.slice(0,10)) throw Error('Elegí una fecha válida.');
    return date.toISOString();
  }
  function inputDate(date = new Date()) {
    const time = new Intl.DateTimeFormat('en-GB', {timeZone:ZONE,hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(date);
    return dateKey(date)+'T'+time;
  }
  function dateLabel(value, now = new Date()) {
    const date = new Date(value), key = dateKey(date), today = dateKey(now), tomorrow = dateKey(new Date(+now+86400000));
    const prefix = key === today ? 'Hoy' : key === tomorrow ? 'Mañana' : date.toLocaleDateString('es-UY',{timeZone:ZONE,weekday:'short',day:'numeric',month:'short'});
    return prefix+' · '+date.toLocaleTimeString('es-UY',{timeZone:ZONE,hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
  }
  function initials(name) { return String(name || '?').trim().split(/\s+/).slice(0,2).map(w=>Array.from(w)[0]||'').join('').toUpperCase(); }
  function safePhoto(value) {
    try { const u = new URL(value); return u.protocol === 'https:' && !u.username && !u.password ? u.href : ''; } catch { return ''; }
  }
  function matchesSearch(plan, query) {
    return normalize([plan.title,plan.category,plan.neighborhood,plan.meeting_point,plan.description].join(' ')).includes(normalize(query).trim());
  }
  function mergeUnique(first, second) { return [...new Map([...first,...second].map(p=>[p.id,p])).values()]; }
  return {ZONE,escapeHTML,normalize,participants,owns,attends,freeSeats,nextSeat,dateKey,dateWindow,inputToISO,inputDate,dateLabel,initials,safePhoto,matchesSearch,mergeUnique};
});
