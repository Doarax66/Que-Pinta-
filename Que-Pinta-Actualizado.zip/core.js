/* Shared, dependency-free rules used by the web app and its checks. */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.PintaCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const ZONE = 'America/Montevideo';
  const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const normalize = value => String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  function participants(plan) { return plan.pinta_participants || []; }
  function owns(plan, user) { return !!user && plan.owner_id === user.id; }
  function attends(plan, user) { return owns(plan, user) || !!user && participants(plan).some(m => m.user_id === user.id); }
  function freeSeats(plan) { return Math.max(0, Number(plan.capacity) - 1 - participants(plan).length); }
  function nextSeat(plan) {
    const used = new Set(participants(plan).map(m => Number(m.seat)));
    for (let seat = 2; seat <= Number(plan.capacity); seat++) if (!used.has(seat)) return seat;
    return null;
  }
  function dateKey(date, zone = ZONE) {
    const parts = new Intl.DateTimeFormat('en-CA', {timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(date));
    return ['year','month','day'].map(type => parts.find(p => p.type === type).value).join('-');
  }
  function inputDate(date = new Date(), zone = ZONE) {
    const time = new Intl.DateTimeFormat('en-GB', {timeZone:zone,hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(date);
    return dateKey(date,zone)+'T'+time;
  }
  function inputToISO(value, zone = ZONE) {
    if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value)) throw Error('Elige un día y una hora válidos.');
    const naive=Date.parse(value+':00Z');
    if(!Number.isFinite(naive)||new Date(naive).toISOString().slice(0,16)!==value)throw Error('Elige una fecha válida.');
    // Discover offsets around the target date; never assume a fixed UTC offset.
    const offsets=new Set();
    for(const delta of [-36,-12,0,12,36]) {
      const sample=naive+delta*3600000;
      offsets.add(Date.parse(inputDate(new Date(sample),zone)+':00Z')-sample);
    }
    const candidates=[...offsets].map(o=>naive-o).filter(t=>inputDate(new Date(t),zone)===value);
    if(!candidates.length)throw Error('Esa hora no existe por el cambio de horario. Elige otra hora.');
    if(candidates.length>1)throw Error('Esa hora se repite por el cambio de horario. Elige una hora fuera de ese cambio.');
    return new Date(candidates[0]).toISOString();
  }
  function shiftDate(key, days) {return new Date(Date.parse(key+'T12:00:00Z')+days*86400000).toISOString().slice(0,10);}
  function dateWindow(filter, now = new Date(), zone = ZONE) {
    const key=dateKey(now,zone),midnight=d=>inputToISO(d+'T00:00',zone);
    if(filter==='today')return [now.toISOString(),midnight(shiftDate(key,1))];
    if(filter==='tomorrow')return [midnight(shiftDate(key,1)),midnight(shiftDate(key,2))];
    if(filter==='weekend'){
      const weekday=new Date(key+'T12:00:00Z').getUTCDay(),n=weekday===0?-1:(6-weekday+7)%7;
      return [new Date(Math.max(+now,Date.parse(midnight(shiftDate(key,n))))).toISOString(),midnight(shiftDate(key,n+2))];
    }
    return [now.toISOString(),null];
  }
  // Per-plan local calendar comparison also handles zones changing at midnight.
  function matchesDate(plan, filter, now = new Date()) {
    if(new Date(plan.starts_at)<=now)return false;
    const zone=plan.qp_timezone||ZONE,day=dateKey(plan.starts_at,zone),today=dateKey(now,zone);
    if(filter==='today')return day===today;
    if(filter==='tomorrow')return day===shiftDate(today,1);
    if(filter==='weekend'){
      const weekday=new Date(today+'T12:00:00Z').getUTCDay(),n=weekday===0?-1:(6-weekday+7)%7;
      return day>=shiftDate(today,n)&&day<shiftDate(today,n+2);
    }
    return true;
  }
  function dateLabel(value, now = new Date(), zone = ZONE) {
    const date=new Date(value),key=dateKey(date,zone),today=dateKey(now,zone);
    const prefix=key===today?'Hoy':key===shiftDate(today,1)?'Mañana':date.toLocaleDateString('es',{timeZone:zone,weekday:'short',day:'numeric',month:'short'});
    return prefix+' · '+date.toLocaleTimeString('es',{timeZone:zone,hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
  }
  function isAdult(value, now = new Date()) {
    if(!/^\d{4}-\d{2}-\d{2}$/.test(value)||value<'1900-01-01')return false;
    const parsed=new Date(value+'T00:00:00Z');
    if(!Number.isFinite(+parsed)||parsed.toISOString().slice(0,10)!==value)return false;
    const today=dateKey(now,'UTC'),birthday=Number(value.slice(0,4))+18+value.slice(4);
    return birthday<=today;
  }
  function socialURL(value, network) {
    if(!String(value||'').trim())return '';
    const raw=String(value).trim();
    try{
      const u=new URL(raw.startsWith('@')?'https://www.'+network+'.com/'+raw.slice(1):raw);
      if(u.protocol!=='https:'||u.username||u.password||u.port)return '';
      if(![network+'.com','www.'+network+'.com'].includes(u.hostname))return '';
      if(network==='instagram'&&!/^\/[a-zA-Z0-9_.]{1,30}\/?$/.test(u.pathname))return '';
      if(network==='facebook'&&!/^\/[a-zA-Z0-9.]{1,100}\/?$/.test(u.pathname))return '';
      if(['sharer.php','login.php','l.php','dialog','accounts','redirect','share'].includes(u.pathname.split('/')[1]))return '';
      if(network==='facebook'&&u.pathname==='/profile.php'){
        const id=u.searchParams.get('id');return /^\d{1,30}$/.test(id||'')?'https://www.facebook.com/profile.php?id='+id:'';
      }
      u.search='';u.hash='';return u.href;
    }catch{return '';}
  }
  function validCoordinates(lat, lng) {return typeof lat==='number'&&typeof lng==='number'&&Number.isFinite(lat)&&Number.isFinite(lng)&&Math.abs(lat)<=85.05112878&&Math.abs(lng)<=180;}
  function directionsURL(plan) {
    const query=validCoordinates(plan.qp_latitude,plan.qp_longitude)?plan.qp_latitude+','+plan.qp_longitude:[plan.meeting_point,plan.neighborhood,plan.qp_city||'Montevideo',plan.qp_country_code||'UY'].join(', ');
    return 'https://www.google.com/maps/dir/?api=1&destination='+encodeURIComponent(query);
  }
  function initials(name) { return String(name || '?').trim().split(/\s+/).slice(0,2).map(w=>Array.from(w)[0]||'').join('').toUpperCase(); }
  function safePhoto(value) {
    try { const u = new URL(value); return u.protocol === 'https:' && !u.username && !u.password ? u.href : ''; } catch { return ''; }
  }
  function matchesSearch(plan, query) {
    return normalize([plan.title,plan.category,plan.neighborhood,plan.qp_city,plan.qp_country_code,plan.meeting_point,plan.description].join(' ')).includes(normalize(query).trim());
  }
  function mergeUnique(first, second) { return [...new Map([...first,...second].map(p=>[p.id,p])).values()]; }
  return {ZONE,escapeHTML,normalize,participants,owns,attends,freeSeats,nextSeat,dateKey,dateWindow,inputToISO,inputDate,dateLabel,matchesDate,isAdult,socialURL,validCoordinates,directionsURL,initials,safePhoto,matchesSearch,mergeUnique};
});
