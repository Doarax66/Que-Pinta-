/* Leaflet maps load only when a meeting sheet is opened. No tracking or prefetch. */
window.PintaMaps = (() => {
  const config={tiles:'https://tile.openstreetmap.org/{z}/{x}/{y}.png',search:'https://photon.komoot.io/api/'};
  let lastSearch=0;
  const cache=new Map();
  function configure(value) {
    for(const key of ['tiles','search'])if(typeof value?.[key]==='string'&&value[key].startsWith('https://'))config[key]=value[key];
  }
  function create(element, center, onPick, onError) {
    if(!window.L){onError?.('El mapa no se pudo cargar. Puedes introducir coordenadas o continuar con la dirección.');return null;}
    const map=L.map(element,{scrollWheelZoom:false,worldCopyJump:true,zoomControl:false}).setView(center,13);
    L.tileLayer(config.tiles,{minZoom:2,maxZoom:19,keepBuffer:1,attribution:'© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>'}).on('tileerror',()=>onError?.('No se pudo cargar parte del mapa. Revisa la conexión.')).addTo(map);
    L.control.zoom({position:'bottomright'}).addTo(map);
    let marker=null;
    const pin=L.divIcon({className:'meeting-marker',html:'<span></span>',iconSize:[32,42],iconAnchor:[16,40]});
    function select(lat,lng,notify=false){
      lng=((lng+180)%360+360)%360-180;
      if(!PintaCore.validCoordinates(lat,lng))return;
      if(marker)marker.setLatLng([lat,lng]);
      else {marker=L.marker([lat,lng],{icon:pin,draggable:!!onPick,keyboard:true,title:'Punto de encuentro',alt:'Pin del punto de encuentro'}).addTo(map);marker.on('dragend',()=>{const p=marker.getLatLng();select(p.lat,p.lng,true);});}
      if(notify)onPick?.(lat,lng);
    }
    if(onPick)map.on('click',e=>select(e.latlng.lat,e.latlng.lng,true));
    setTimeout(()=>map.invalidateSize(),120);
    return {select,resize:()=>map.invalidateSize(),center:(lat,lng,zoom=15)=>map.setView([lat,lng],zoom,{animate:!matchMedia('(prefers-reduced-motion: reduce)').matches}),clear:()=>{if(marker)map.removeLayer(marker);marker=null;},remove:()=>map.remove()};
  }
  async function search(query,country,city,center) {
    const text=[query,city].filter(Boolean).join(', '),key=country+'|'+text;
    if(cache.has(key))return cache.get(key);
    if(Date.now()-lastSearch<1500)throw Error('Espera un momento antes de buscar de nuevo.');
    lastSearch=Date.now();
    const url=new URL(config.search);url.searchParams.set('q',text);url.searchParams.set('limit','6');
    if(center){url.searchParams.set('lat',center[0]);url.searchParams.set('lon',center[1]);}
    const response=await fetch(url,{signal:AbortSignal.timeout(10000)});
    if(!response.ok)throw Error('La búsqueda de lugares no está disponible. Puedes marcar el mapa manualmente.');
    const data=await response.json();
    const results=(data.features||[]).filter(f=>f.geometry?.type==='Point'&&PintaCore.validCoordinates(f.geometry.coordinates[1],f.geometry.coordinates[0])&&(!country||String(f.properties?.countrycode||'').toUpperCase()===country)).map(f=>({lat:f.geometry.coordinates[1],lng:f.geometry.coordinates[0],name:[f.properties.name,f.properties.street,f.properties.housenumber,f.properties.city||f.properties.town,f.properties.country].filter(Boolean).join(', ')}));
    if(cache.size>=30)cache.delete(cache.keys().next().value);cache.set(key,results);return results;
  }
  async function locate(){
    if(window.Capacitor?.isNativePlatform?.()){
      const geo=Capacitor.registerPlugin('Geolocation');
      return geo.getCurrentPosition({enableHighAccuracy:false,timeout:12000,maximumAge:60000});
    }
    if(!navigator.geolocation)throw Error('La ubicación no está disponible en este navegador.');
    return new Promise((resolve,reject)=>navigator.geolocation.getCurrentPosition(resolve,reject,{enableHighAccuracy:false,timeout:12000,maximumAge:60000}));
  }
  return {create,search,locate,configure};
})();
