-- Que Pinta 4. Ejecutar completo sobre la versión 3 ya activada.
-- Conserva usuarios y planes. No establece una duración ni finaliza automáticamente.
begin;
do $$ begin
 if not exists(select 1 from public.qp_app_config where key='release' and (value->>'adultDeclaration')::boolean) then
  raise exception 'Primero activa la versión 3';
 end if;
end $$;
alter table public.pinta_plans
 add column if not exists qp_mode text not null default 'presential',
 add column if not exists qp_platform text not null default '',
 add column if not exists qp_server_region text not null default '',
 add column if not exists qp_finished_at timestamptz;
alter table public.pinta_plans alter column qp_country_code drop not null,
 alter column qp_city drop not null,alter column qp_currency drop not null;
alter table public.pinta_plans drop constraint if exists qp_location_valid;
alter table public.pinta_plans drop constraint if exists qp_v4_location;
alter table public.pinta_plans add constraint qp_v4_location check (
 qp_mode in ('presential','online') and length(qp_platform)<=40 and length(qp_server_region)<=60
 and (qp_cost is null or qp_cost between 0 and 100000)
 and ((qp_mode='online' and qp_country_code is null and qp_city is null and qp_currency is null
       and qp_latitude is null and qp_longitude is null and qp_cost is not null and qp_cost=0)
 or (qp_mode='presential' and qp_country_code is not null and qp_country_code ~ '^[A-Z]{2}$'
     and qp_city is not null and length(btrim(qp_city)) between 1 and 80
     and ((qp_currency is not null and qp_currency ~ '^[A-Z]{3}$') or ((qp_cost is null or qp_cost=0) and qp_currency is null))
     and ((qp_latitude is null and qp_longitude is null) or
       (qp_latitude is not null and qp_longitude is not null and qp_latitude between -85.05112878 and 85.05112878 and qp_longitude between -180 and 180))))
);
create index if not exists qp_active_mode_date on public.pinta_plans(qp_mode,starts_at,id) where qp_finished_at is null;
create index if not exists qp_owner_history on public.pinta_plans(owner_id,qp_finished_at,starts_at);
grant select(qp_mode,qp_platform,qp_server_region,qp_finished_at) on public.pinta_plans to anon,authenticated;
grant insert(qp_mode,qp_platform,qp_server_region),update(qp_finished_at) on public.pinta_plans to authenticated;

drop policy if exists qp_v4_finish_owner on public.pinta_plans;
create policy qp_v4_finish_owner on public.pinta_plans for update to authenticated
 using(owner_id=(select auth.uid()) and qp_finished_at is null and starts_at<=now())
 with check(owner_id=(select auth.uid()) and qp_finished_at is not null);

-- Invoker triggers preserve the existing ownership RLS, including for older clients.
create or replace function qp_private.qp_lifecycle() returns trigger language plpgsql security invoker set search_path='' as $$
begin
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(coalesce(new.id,old.id)::text,4));
 if tg_op='INSERT' then
  if new.qp_mode='online' then new.qp_currency=null; else new.qp_currency=('{"AD": "EUR", "AE": "AED", "AF": "AFN", "AG": "XCD", "AI": "XCD", "AL": "ALL", "AM": "AMD", "AO": "AOA", "AR": "ARS", "AS": "USD", "AT": "EUR", "AU": "AUD", "AW": "AWG", "AX": "EUR", "AZ": "AZN", "BA": "BAM", "BB": "BBD", "BD": "BDT", "BE": "EUR", "BF": "XOF", "BG": "EUR", "BH": "BHD", "BI": "BIF", "BJ": "XOF", "BL": "EUR", "BM": "BMD", "BN": "BND", "BO": "BOB", "BQ": "USD", "BR": "BRL", "BS": "BSD", "BT": "BTN", "BW": "BWP", "BY": "BYN", "BZ": "BZD", "CA": "CAD", "CC": "AUD", "CD": "CDF", "CF": "XAF", "CG": "XAF", "CH": "CHF", "CI": "XOF", "CK": "NZD", "CL": "CLP", "CM": "XAF", "CN": "CNY", "CO": "COP", "CR": "CRC", "CU": "CUP", "CV": "CVE", "CW": "XCG", "CX": "AUD", "CY": "EUR", "CZ": "CZK", "DE": "EUR", "DJ": "DJF", "DK": "DKK", "DM": "XCD", "DO": "DOP", "DZ": "DZD", "EC": "USD", "EE": "EUR", "EG": "EGP", "EH": "MAD", "ER": "ERN", "ES": "EUR", "ET": "ETB", "FI": "EUR", "FJ": "FJD", "FK": "FKP", "FM": "USD", "FO": "DKK", "FR": "EUR", "GA": "XAF", "GB": "GBP", "GD": "XCD", "GE": "GEL", "GF": "EUR", "GG": "GBP", "GH": "GHS", "GI": "GIP", "GL": "DKK", "GM": "GMD", "GN": "GNF", "GP": "EUR", "GQ": "XAF", "GR": "EUR", "GS": "GBP", "GT": "GTQ", "GU": "USD", "GW": "XOF", "GY": "GYD", "HK": "HKD", "HN": "HNL", "HR": "EUR", "HT": "HTG", "HU": "HUF", "ID": "IDR", "IE": "EUR", "IL": "ILS", "IM": "GBP", "IN": "INR", "IO": "USD", "IQ": "IQD", "IR": "IRR", "IS": "ISK", "IT": "EUR", "JE": "GBP", "JM": "JMD", "JO": "JOD", "JP": "JPY", "KE": "KES", "KG": "KGS", "KH": "KHR", "KI": "AUD", "KM": "KMF", "KN": "XCD", "KP": "KPW", "KR": "KRW", "KW": "KWD", "KY": "KYD", "KZ": "KZT", "LA": "LAK", "LB": "LBP", "LC": "XCD", "LI": "CHF", "LK": "LKR", "LR": "LRD", "LS": "ZAR", "LT": "EUR", "LU": "EUR", "LV": "EUR", "LY": "LYD", "MA": "MAD", "MC": "EUR", "MD": "MDL", "ME": "EUR", "MF": "EUR", "MG": "MGA", "MH": "USD", "MK": "MKD", "ML": "XOF", "MM": "MMK", "MN": "MNT", "MO": "MOP", "MP": "USD", "MQ": "EUR", "MR": "MRU", "MS": "XCD", "MT": "EUR", "MU": "MUR", "MV": "MVR", "MW": "MWK", "MX": "MXN", "MY": "MYR", "MZ": "MZN", "NA": "NAD", "NC": "XPF", "NE": "XOF", "NF": "AUD", "NG": "NGN", "NI": "NIO", "NL": "EUR", "NO": "NOK", "NP": "NPR", "NR": "AUD", "NU": "NZD", "NZ": "NZD", "OM": "OMR", "PA": "PAB", "PE": "PEN", "PF": "XPF", "PG": "PGK", "PH": "PHP", "PK": "PKR", "PL": "PLN", "PM": "EUR", "PN": "NZD", "PR": "USD", "PS": "ILS", "PT": "EUR", "PW": "USD", "PY": "PYG", "QA": "QAR", "RE": "EUR", "RO": "RON", "RS": "RSD", "RU": "RUB", "RW": "RWF", "SA": "SAR", "SB": "SBD", "SC": "SCR", "SD": "SDG", "SE": "SEK", "SG": "SGD", "SH": "SHP", "SI": "EUR", "SJ": "NOK", "SK": "EUR", "SL": "SLE", "SM": "EUR", "SN": "XOF", "SO": "SOS", "SR": "SRD", "SS": "SSP", "ST": "STN", "SV": "USD", "SX": "XCG", "SY": "SYP", "SZ": "SZL", "TC": "USD", "TD": "XAF", "TF": "EUR", "TG": "XOF", "TH": "THB", "TJ": "TJS", "TK": "NZD", "TL": "USD", "TM": "TMT", "TN": "TND", "TO": "TOP", "TR": "TRY", "TT": "TTD", "TV": "AUD", "TW": "TWD", "TZ": "TZS", "UA": "UAH", "UG": "UGX", "UM": "USD", "US": "USD", "UY": "UYU", "UZ": "UZS", "VA": "EUR", "VC": "XCD", "VE": "VES", "VG": "USD", "VI": "USD", "VN": "VND", "VU": "VUV", "WF": "XPF", "WS": "WST", "YE": "YER", "YT": "EUR", "ZA": "ZAR", "ZM": "ZMW", "ZW": "USD"}'::jsonb)->>new.qp_country_code; end if;
  if new.qp_finished_at is not null then raise exception 'El plan debe comenzar activo'; end if;
  return new;
 end if;
 if old.qp_finished_at is not null then raise exception 'El plan finalizado se conserva en el historial'; end if;
 if tg_op='DELETE' then return old; end if;
 if new.owner_id is distinct from old.owner_id or new.id is distinct from old.id then raise exception 'No se puede cambiar el organizador'; end if;
 if new.qp_finished_at is not null then
  if (select auth.uid()) is distinct from old.owner_id then raise exception 'Solo el organizador puede finalizar'; end if;
  if old.starts_at>now() then raise exception 'El plan todavía no comenzó'; end if;
  if (to_jsonb(new)-'qp_finished_at') is distinct from (to_jsonb(old)-'qp_finished_at') then raise exception 'Finaliza sin cambiar los demás datos'; end if;
  new.qp_finished_at=now();
 end if;
 return new;
end $$;
revoke all on function qp_private.qp_lifecycle() from public,anon,authenticated;
drop trigger if exists qp_v4_lifecycle on public.pinta_plans;
create trigger qp_v4_lifecycle before insert or update or delete on public.pinta_plans for each row execute function qp_private.qp_lifecycle();
create or replace function qp_private.qp_membership_lifecycle() returns trigger language plpgsql security invoker set search_path='' as $$
declare p public.pinta_plans;
begin
 if tg_op='UPDATE' and (new.plan_id is distinct from old.plan_id or new.user_id is distinct from old.user_id) then raise exception 'No se puede transferir la inscripción'; end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(coalesce(new.plan_id,old.plan_id)::text,4));
 select * into p from public.pinta_plans where id=coalesce(new.plan_id,old.plan_id);
 if p.qp_finished_at is not null then raise exception 'Los participantes del plan finalizado se conservan'; end if;
 if tg_op<>'DELETE' then
  if p.id is null or p.starts_at<=now() then raise exception 'El plan ya comenzó o no existe'; end if;
  if new.seat>p.capacity or new.user_id=p.owner_id then raise exception 'Plaza no válida'; end if;
  return new;
 end if;
 return old;
end $$;
revoke all on function qp_private.qp_membership_lifecycle() from public,anon,authenticated;
drop trigger if exists qp_v4_membership on public.pinta_participants;
create trigger qp_v4_membership before insert or update or delete on public.pinta_participants for each row execute function qp_private.qp_membership_lifecycle();

-- One assessment of the experience by its organizer; only its group can read it.
do $$ declare plan_type text; begin
 select format_type(atttypid,atttypmod) into plan_type from pg_attribute where attrelid='public.pinta_plans'::regclass and attname='id';
 if plan_type not in ('uuid','bigint','integer','text','character varying') then raise exception 'Tipo de plan no admitido: %',plan_type;end if;
 execute format('create table if not exists public.qp_plan_reviews(plan_id %s primary key references public.pinta_plans(id) on delete cascade,author_id uuid not null references auth.users(id),rating integer not null check(rating between 1 and 3),comment text not null default '''' check(length(comment)<=400))',plan_type);
end $$;
alter table public.qp_plan_reviews enable row level security;
revoke all on public.qp_plan_reviews from public,anon,authenticated;
grant select,insert on public.qp_plan_reviews to authenticated;
grant update(rating,comment) on public.qp_plan_reviews to authenticated;
drop policy if exists qp_review_read on public.qp_plan_reviews;
create policy qp_review_read on public.qp_plan_reviews for select to authenticated using(exists(
 select 1 from public.pinta_plans p where p.id=plan_id and p.qp_finished_at is not null and
 (p.owner_id=(select auth.uid()) or exists(select 1 from public.pinta_participants m where m.plan_id=p.id and m.user_id=(select auth.uid())))));
drop policy if exists qp_review_insert on public.qp_plan_reviews;
create policy qp_review_insert on public.qp_plan_reviews for insert to authenticated with check(
 author_id=(select auth.uid()) and exists(select 1 from public.pinta_plans p where p.id=plan_id and p.owner_id=(select auth.uid()) and p.qp_finished_at is not null));
drop policy if exists qp_review_update on public.qp_plan_reviews;
create policy qp_review_update on public.qp_plan_reviews for update to authenticated using(author_id=(select auth.uid())) with check(author_id=(select auth.uid()) and exists(select 1 from public.pinta_plans p where p.id=plan_id and p.owner_id=(select auth.uid()) and p.qp_finished_at is not null));

-- Private requests. An accepted friendship requires action by the recipient.
create table if not exists public.qp_friendships(
 id uuid primary key default gen_random_uuid(),sender_id uuid not null references auth.users(id) on delete cascade,
 receiver_id uuid not null references auth.users(id) on delete cascade,
 status text not null default 'pending' check(status in ('pending','accepted')),
 created_at timestamptz not null default now(),check(sender_id<>receiver_id)
);
create unique index if not exists qp_friend_pair on public.qp_friendships(least(sender_id,receiver_id),greatest(sender_id,receiver_id));
create index if not exists qp_friend_receiver on public.qp_friendships(receiver_id,status);
create index if not exists qp_friend_sender on public.qp_friendships(sender_id,status);
alter table public.qp_friendships enable row level security;
revoke all on public.qp_friendships from public,anon,authenticated;
grant select,delete on public.qp_friendships to authenticated;
grant insert(sender_id,receiver_id),update(status) on public.qp_friendships to authenticated;
drop policy if exists qp_friend_read on public.qp_friendships;
create policy qp_friend_read on public.qp_friendships for select to authenticated using((select auth.uid()) in(sender_id,receiver_id));
drop policy if exists qp_friend_insert on public.qp_friendships;
create policy qp_friend_insert on public.qp_friendships for insert to authenticated with check(
 sender_id=(select auth.uid()) and status='pending' and exists(select 1 from public.qp_age_declarations where user_id=(select auth.uid())) and exists(
 select 1 from public.pinta_plans p where p.qp_finished_at is not null and
 (p.owner_id=sender_id or exists(select 1 from public.pinta_participants m where m.plan_id=p.id and m.user_id=sender_id)) and
 (p.owner_id=receiver_id or exists(select 1 from public.pinta_participants m where m.plan_id=p.id and m.user_id=receiver_id))));
drop policy if exists qp_friend_accept on public.qp_friendships;
create policy qp_friend_accept on public.qp_friendships for update to authenticated
 using(receiver_id=(select auth.uid()) and status='pending') with check(receiver_id=(select auth.uid()) and status='accepted');
drop policy if exists qp_friend_delete on public.qp_friendships;
create policy qp_friend_delete on public.qp_friendships for delete to authenticated using((select auth.uid()) in(sender_id,receiver_id));
-- Column grants are reinforced by a trigger for owners with legacy table grants.
create or replace function qp_private.qp_friend_guard() returns trigger language plpgsql security invoker set search_path='' as $$
begin
 if tg_op='INSERT' then
  if new.status<>'pending' then raise exception 'La solicitud debe ser aceptada por su destinatario'; end if;
 elsif new.sender_id is distinct from old.sender_id or new.receiver_id is distinct from old.receiver_id
  or new.id is distinct from old.id or new.created_at is distinct from old.created_at then
  raise exception 'No se pueden cambiar las personas de una solicitud';
 elsif (select auth.uid()) is distinct from old.receiver_id or old.status<>'pending' or new.status<>'accepted' then
  raise exception 'Solo el destinatario puede aceptar';
 end if;return new;
end $$;
revoke all on function qp_private.qp_friend_guard() from public,anon,authenticated;
drop trigger if exists qp_friend_guard on public.qp_friendships;
create trigger qp_friend_guard before insert or update on public.qp_friendships for each row execute function qp_private.qp_friend_guard();
insert into public.qp_app_config(key,value) values('release-v4','{"version":4}') on conflict(key) do update set value=excluded.value;
notify pgrst,'reload schema';
commit;
select 'Actualización 4 lista' as resultado;
