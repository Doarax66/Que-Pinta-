-- Que Pinta 2 · Instalación opcional de perfiles públicos, chat y costos.
-- Ejecutar una vez en el SQL Editor del MISMO proyecto Supabase.
-- No elimina ni modifica filas ni políticas de pinta_plans / pinta_participants.
-- Este archivo es un instalador para el proyecto existente, no una migración aplicada.
-- Antes de ejecutar: conservar el código anterior y revisar las políticas existentes.
-- La transacción se revierte por completo si falta una tabla o hay incompatibilidades.

begin;

do $install$
declare
  plan_key_type text;
begin
  if to_regclass('public.pinta_plans') is null or to_regclass('public.pinta_participants') is null then
    raise exception 'Faltan las tablas originales pinta_plans y pinta_participants. Usá el proyecto Supabase de Que Pinta.';
  end if;
  if exists (
    select 1 from pg_class where oid in ('public.pinta_plans'::regclass,'public.pinta_participants'::regclass)
    and not relrowsecurity
  ) then
    raise exception 'Las tablas originales deben tener RLS activado y sus políticas revisadas antes de habilitar chats.';
  end if;
  select format_type(atttypid,atttypmod) into plan_key_type
  from pg_attribute where attrelid='public.pinta_plans'::regclass and attname='id' and not attisdropped;
  if plan_key_type not in ('uuid','bigint','integer','text','character varying') then
    raise exception 'Revisar el tipo de ID de los planes: %',plan_key_type;
  end if;
  execute format($ddl$
    create table if not exists public.qp_plan_details (
      plan_id %s primary key references public.pinta_plans(id) on delete cascade,
      cost_uyu integer check (cost_uyu between 0 and 100000)
    )
  $ddl$,plan_key_type);
  execute format($ddl$
    create table if not exists public.qp_messages (
      id uuid primary key default gen_random_uuid(),
      plan_id %s not null references public.pinta_plans(id) on delete cascade,
      user_id uuid not null references auth.users(id) on delete cascade,
      display_name text not null check (char_length(btrim(display_name)) between 1 and 40),
      body text not null check (char_length(btrim(body)) between 1 and 1000),
      created_at timestamptz not null default now()
    )
  $ddl$,plan_key_type);
end
$install$;

create table if not exists public.qp_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(btrim(display_name)) between 1 and 40),
  bio text not null default '' check (char_length(bio)<=240),
  avatar_url text not null default '' check (
    char_length(avatar_url)<=500 and (avatar_url='' or avatar_url ~ '^https://[^[:space:]]+$')
  ),
  interests text[] not null default '{}' check (
    cardinality(interests)<=4 and interests <@ array['Deporte','Comida','Juegos','Paseos']::text[]
  )
);

alter table public.qp_profiles enable row level security;
alter table public.qp_messages enable row level security;
alter table public.qp_plan_details enable row level security;

-- El instalador solo reemplaza políticas con sus propios nombres.
drop policy if exists qp_profiles_read on public.qp_profiles;
drop policy if exists qp_profiles_create_self on public.qp_profiles;
drop policy if exists qp_profiles_edit_self on public.qp_profiles;
create policy qp_profiles_read on public.qp_profiles for select to anon,authenticated using(true);
create policy qp_profiles_create_self on public.qp_profiles for insert to authenticated
  with check(id=(select auth.uid()));
create policy qp_profiles_edit_self on public.qp_profiles for update to authenticated
  using(id=(select auth.uid())) with check(id=(select auth.uid()));

-- Un visitante o una persona ajena al grupo nunca puede leer mensajes.
-- Las comprobaciones se realizan en Postgres, no solo en la interfaz.
drop policy if exists qp_messages_read_members on public.qp_messages;
drop policy if exists qp_messages_send_members on public.qp_messages;
create policy qp_messages_read_members on public.qp_messages for select to authenticated using (
  exists(select 1 from public.pinta_plans p where p.id=qp_messages.plan_id and p.owner_id=(select auth.uid()))
  or exists(select 1 from public.pinta_participants m where m.plan_id=qp_messages.plan_id and m.user_id=(select auth.uid()))
);
create policy qp_messages_send_members on public.qp_messages for insert to authenticated with check (
  user_id=(select auth.uid()) and (
    exists(select 1 from public.pinta_plans p where p.id=qp_messages.plan_id and p.owner_id=(select auth.uid()))
    or exists(select 1 from public.pinta_participants m where m.plan_id=qp_messages.plan_id and m.user_id=(select auth.uid()))
  )
);

drop policy if exists qp_details_read on public.qp_plan_details;
drop policy if exists qp_details_create_owner on public.qp_plan_details;
drop policy if exists qp_details_edit_owner on public.qp_plan_details;
create policy qp_details_read on public.qp_plan_details for select to anon,authenticated using (
  exists(select 1 from public.pinta_plans p where p.id=qp_plan_details.plan_id)
);
create policy qp_details_create_owner on public.qp_plan_details for insert to authenticated with check (
  exists(select 1 from public.pinta_plans p where p.id=qp_plan_details.plan_id and p.owner_id=(select auth.uid()))
);
create policy qp_details_edit_owner on public.qp_plan_details for update to authenticated using (
  exists(select 1 from public.pinta_plans p where p.id=qp_plan_details.plan_id and p.owner_id=(select auth.uid()))
) with check (
  exists(select 1 from public.pinta_plans p where p.id=qp_plan_details.plan_id and p.owner_id=(select auth.uid()))
);

revoke all on public.qp_profiles,public.qp_messages,public.qp_plan_details from public,anon,authenticated;
grant select on public.qp_profiles,public.qp_plan_details to anon,authenticated;
grant insert,update on public.qp_profiles,public.qp_plan_details to authenticated;
grant select on public.qp_messages to authenticated;
-- No se acepta un created_at suministrado por el cliente.
grant insert(id,plan_id,user_id,display_name,body) on public.qp_messages to authenticated;

create index if not exists qp_messages_plan_date_idx on public.qp_messages(plan_id,created_at desc,id desc);
create index if not exists qp_messages_author_idx on public.qp_messages(user_id);

notify pgrst,'reload schema';
commit;

-- Inspección de las nuevas tablas. RLS debe ser true en las tres.
select c.relname as tabla,c.relrowsecurity as rls
from pg_class c join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public' and c.relname in ('qp_profiles','qp_messages','qp_plan_details');
