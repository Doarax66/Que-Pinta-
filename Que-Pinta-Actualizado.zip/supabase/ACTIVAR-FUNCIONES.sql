-- Que Pinta 3 · Actualización del proyecto existente.
-- Ejecutar TODO este archivo una vez en el SQL Editor de duieibwtyxrqfzlhqbap.
-- Conserva cuentas, planes, inscripciones y políticas anteriores.
-- Añade políticas RESTRICTIVAS de edad: las versiones antiguas necesitan que
-- cada cuenta declare su fecha en la versión 3 antes de crear/unirse/conversar.
-- Es declaración de edad (18+), NO verificación de identidad ni de documento.
-- Los nuevos registros necesitan birth_date; los existentes no se eliminan.
-- Es un instalador revisable; no es una migración ya aplicada a producción.

begin;

do $install$
declare
  plan_key_type text;
begin
  if to_regclass('public.pinta_plans') is null or to_regclass('public.pinta_participants') is null then
    raise exception 'Faltan las tablas originales pinta_plans y pinta_participants. Usá el proyecto Supabase de Que Pinta.';
  end if;
  if exists (
    select 1 from pg_class where oid in ('public.pinta_plans'::regclass,'public.pinta_participants'::regclass)
    and not relrowsecurity
  ) then
    raise exception 'Las tablas originales deben tener RLS activado y sus políticas revisadas antes de habilitar chats.';
  end if;
  select format_type(atttypid,atttypmod) into plan_key_type
  from pg_attribute where attrelid='public.pinta_plans'::regclass and attname='id' and not attisdropped;
  if plan_key_type not in ('uuid','bigint','integer','text','character varying') then
    raise exception 'Revisar el tipo de ID de los planes: %',plan_key_type;
  end if;
  execute format($ddl$
    create table if not exists public.qp_plan_details (
      plan_id %s primary key references public.pinta_plans(id) on delete cascade,
      cost_uyu integer check (cost_uyu between 0 and 100000)
    )
  $ddl$,plan_key_type);
  execute format($ddl$
    create table if not exists public.qp_messages (
      id uuid primary key default gen_random_uuid(),
      plan_id %s not null references public.pinta_plans(id) on delete cascade,
      user_id uuid not null references auth.users(id) on delete cascade,
      display_name text not null check (char_length(btrim(display_name)) between 1 and 40),
      body text not null check (char_length(btrim(body)) between 1 and 1000),
      created_at timestamptz not null default now()
    )
  $ddl$,plan_key_type);
end
$install$;

create table if not exists public.qp_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(btrim(display_name)) between 1 and 40),
  bio text not null default '' check (char_length(bio)<=240),
  avatar_url text not null default '' check (
    char_length(avatar_url)<=500 and (avatar_url='' or avatar_url ~ '^https://[^[:space:]]+$')
  ),
  interests text[] not null default '{}' check (
    cardinality(interests)<=4 and interests <@ array['Deporte','Comida','Juegos','Paseos']::text[]
  )
);

alter table public.qp_profiles enable row level security;
alter table public.qp_messages enable row level security;
alter table public.qp_plan_details enable row level security;

-- El instalador solo reemplaza políticas con sus propios nombres.
drop policy if exists qp_profiles_read on public.qp_profiles;
drop policy if exists qp_profiles_create_self on public.qp_profiles;
drop policy if exists qp_profiles_edit_self on public.qp_profiles;
create policy qp_profiles_read on public.qp_profiles for select to anon,authenticated using(true);
create policy qp_profiles_create_self on public.qp_profiles for insert to authenticated
  with check(id=(select auth.uid()));
create policy qp_profiles_edit_self on public.qp_profiles for update to authenticated
  using(id=(select auth.uid())) with check(id=(select auth.uid()));

-- Un visitante o una persona ajena al grupo nunca puede leer mensajes.
-- Las comprobaciones se realizan en Postgres, no solo en la interfaz.
drop policy if exists qp_messages_read_members on public.qp_messages;
drop policy if exists qp_messages_send_members on public.qp_messages;
create policy qp_messages_read_members on public.qp_messages for select to authenticated using (
  exists(select 1 from public.pinta_plans p where p.id=qp_messages.plan_id and p.owner_id=(select auth.uid()))
  or exists(select 1 from public.pinta_participants m where m.plan_id=qp_messages.plan_id and m.user_id=(select auth.uid()))
);
create policy qp_messages_send_members on public.qp_messages for insert to authenticated with check (
  user_id=(select auth.uid()) and (
    exists(select 1 from public.pinta_plans p where p.id=qp_messages.plan_id and p.owner_id=(select auth.uid()))
    or exists(select 1 from public.pinta_participants m where m.plan_id=qp_messages.plan_id and m.user_id=(select auth.uid()))
  )
);

drop policy if exists qp_details_read on public.qp_plan_details;
drop policy if exists qp_details_create_owner on public.qp_plan_details;
drop policy if exists qp_details_edit_owner on public.qp_plan_details;
create policy qp_details_read on public.qp_plan_details for select to anon,authenticated using (
  exists(select 1 from public.pinta_plans p where p.id=qp_plan_details.plan_id)
);
create policy qp_details_create_owner on public.qp_plan_details for insert to authenticated with check (
  exists(select 1 from public.pinta_plans p where p.id=qp_plan_details.plan_id and p.owner_id=(select auth.uid()))
);
create policy qp_details_edit_owner on public.qp_plan_details for update to authenticated using (
  exists(select 1 from public.pinta_plans p where p.id=qp_plan_details.plan_id and p.owner_id=(select auth.uid()))
) with check (
  exists(select 1 from public.pinta_plans p where p.id=qp_plan_details.plan_id and p.owner_id=(select auth.uid()))
);

revoke all on public.qp_profiles,public.qp_messages,public.qp_plan_details from public,anon,authenticated;
grant select on public.qp_profiles,public.qp_plan_details to anon,authenticated;
grant insert,update on public.qp_profiles,public.qp_plan_details to authenticated;
grant select on public.qp_messages to authenticated;
-- No se acepta un created_at suministrado por el cliente.
grant insert(id,plan_id,user_id,display_name,body) on public.qp_messages to authenticated;

create index if not exists qp_messages_plan_date_idx on public.qp_messages(plan_id,created_at desc,id desc);
create index if not exists qp_messages_author_idx on public.qp_messages(user_id);

-- Si el prototipo tenía una lista CHECK de los cuatro barrios iniciales,
-- sustituir solo esa lista por la validación de longitud; conservar otras reglas.
do $neighborhood$
declare r record; target_att smallint;
begin
  select attnum into target_att from pg_attribute where attrelid='public.pinta_plans'::regclass and attname='neighborhood';
  for r in select oid,conname from pg_constraint where conrelid='public.pinta_plans'::regclass
    and contype='c' and conkey=array[target_att] loop
    if pg_get_constraintdef(r.oid) like '%Palermo%' and pg_get_constraintdef(r.oid) like '%Parque Rodó%'
       and pg_get_constraintdef(r.oid) like '%Pocitos%' and pg_get_constraintdef(r.oid) like '%Centro%'
       and pg_get_constraintdef(r.oid) like 'CHECK ((neighborhood = ANY (ARRAY[%'
       and pg_get_constraintdef(r.oid) like '%])))'
       and length(pg_get_constraintdef(r.oid))-length(replace(pg_get_constraintdef(r.oid),chr(39),''))=8
       and pg_get_constraintdef(r.oid) !~ '\m(AND|OR|NOT)\M' then
      execute format('alter table public.pinta_plans drop constraint %I',r.conname);
    end if;
  end loop;
  if not exists(select 1 from pg_constraint where conrelid='public.pinta_plans'::regclass and conname='qp_neighborhood_length') then
    alter table public.pinta_plans add constraint qp_neighborhood_length check(char_length(btrim(neighborhood)) between 1 and 60) not valid;
  end if;
end $neighborhood$;

-- La ubicación y el costo se insertan en la MISMA fila: no hay planes a medias.
alter table public.pinta_plans
  add column if not exists qp_country_code text not null default 'UY',
  add column if not exists qp_city text not null default 'Montevideo',
  add column if not exists qp_timezone text not null default 'America/Montevideo',
  add column if not exists qp_latitude double precision,
  add column if not exists qp_longitude double precision,
  add column if not exists qp_cost numeric(10,2),
  add column if not exists qp_currency text not null default 'UYU';

do $constraints$
begin
  if not exists(select 1 from pg_constraint where conrelid='public.pinta_plans'::regclass and conname='qp_location_valid') then
    alter table public.pinta_plans add constraint qp_location_valid check (
      qp_country_code ~ '^[A-Z]{2}$' and char_length(btrim(qp_city)) between 1 and 80
      and ((qp_latitude is null and qp_longitude is null) or
        (qp_latitude is not null and qp_longitude is not null and
         qp_latitude between -85.05112878 and 85.05112878 and qp_longitude between -180 and 180))
      and (qp_cost is null or qp_cost between 0 and 100000)
      and qp_currency ~ '^[A-Z]{3}$'
    );
  end if;
end $constraints$;

-- Importar los costos opcionales de v2, si se habían utilizado.
update public.pinta_plans p set qp_cost=d.cost_uyu,qp_currency='UYU'
from public.qp_plan_details d where p.id=d.plan_id and p.qp_cost is null and d.cost_uyu is not null;
create index if not exists qp_country_upcoming on public.pinta_plans(qp_country_code,starts_at,id);

alter table public.qp_profiles
  add column if not exists instagram_url text not null default '',
  add column if not exists facebook_url text not null default '';

do $socials$
begin
  if not exists(select 1 from pg_constraint where conrelid='public.qp_profiles'::regclass and conname='qp_social_urls') then
    alter table public.qp_profiles add constraint qp_social_urls check (
      char_length(instagram_url)<=250 and char_length(facebook_url)<=250
      and (instagram_url='' or instagram_url ~ '^https://(www\.)?instagram\.com/[A-Za-z0-9_.]{1,30}/?$')
      and (facebook_url='' or facebook_url ~ '^https://(www\.)?facebook\.com/[A-Za-z0-9.]{1,100}/?(\?id=[0-9]{1,30})?$')
    );
  end if;
end $socials$;

-- La fecha no forma parte de qp_profiles. Solo su titular puede consultar su fila.
create table if not exists public.qp_age_declarations (
  user_id uuid primary key references auth.users(id) on delete cascade,
  birth_date date not null,
  declared_at timestamptz not null default now()
);
alter table public.qp_age_declarations enable row level security;
revoke all on public.qp_age_declarations from public,anon,authenticated;
grant select(user_id),insert(user_id,birth_date) on public.qp_age_declarations to authenticated;
grant insert(user_id,birth_date) on public.qp_age_declarations to supabase_auth_admin;
drop policy if exists qp_age_read_self on public.qp_age_declarations;
drop policy if exists qp_age_insert_self on public.qp_age_declarations;
drop policy if exists qp_age_auth_insert on public.qp_age_declarations;
create policy qp_age_read_self on public.qp_age_declarations for select to authenticated
  using(user_id=(select auth.uid()));
create policy qp_age_insert_self on public.qp_age_declarations for insert to authenticated
  with check(user_id=(select auth.uid()));
create policy qp_age_auth_insert on public.qp_age_declarations for insert to supabase_auth_admin
  with check(true);

create schema if not exists qp_private;
revoke all on schema qp_private from public,anon,authenticated;
grant usage on schema qp_private,public to supabase_auth_admin;
-- Invoker functions: no SECURITY DEFINER and no JWT metadata used for authorization.
create or replace function qp_private.check_declared_age()
returns trigger language plpgsql security invoker set search_path='' as $fn$
begin
  if new.birth_date < date '1900-01-01' or
     new.birth_date > ((now() at time zone 'UTC')::date - interval '18 years')::date then
    raise exception 'Debes tener al menos 18 años para participar en Que Pinta.';
  end if;
  return new;
end $fn$;
revoke all on function qp_private.check_declared_age() from public,anon,authenticated;
drop trigger if exists qp_validate_age on public.qp_age_declarations;
create trigger qp_validate_age before insert or update on public.qp_age_declarations
for each row execute function qp_private.check_declared_age();

create or replace function qp_private.register_declared_age()
returns trigger language plpgsql security invoker set search_path='' as $fn$
declare birthday date;
begin
  if coalesce(new.raw_user_meta_data->>'birth_date','') !~ '^\d{4}-\d{2}-\d{2}$' then
    raise exception 'Indica una fecha de nacimiento válida para registrarte en Que Pinta.';
  end if;
  birthday := (new.raw_user_meta_data->>'birth_date')::date;
  insert into public.qp_age_declarations(user_id,birth_date) values(new.id,birthday);
  return new;
end $fn$;
revoke all on function qp_private.register_declared_age() from public,anon,authenticated;
grant execute on function qp_private.register_declared_age(),qp_private.check_declared_age() to supabase_auth_admin;
drop trigger if exists qp_register_age on auth.users;
create trigger qp_register_age after insert on auth.users
for each row execute function qp_private.register_declared_age();

-- Restrictive policies combine with the existing ownership/membership rules using AND.
drop policy if exists qp_adults_create_plan on public.pinta_plans;
create policy qp_adults_create_plan on public.pinta_plans as restrictive for insert to authenticated
with check(exists(select 1 from public.qp_age_declarations a where a.user_id=(select auth.uid())));
drop policy if exists qp_adults_edit_plan on public.pinta_plans;
create policy qp_adults_edit_plan on public.pinta_plans as restrictive for update to authenticated
using(exists(select 1 from public.qp_age_declarations a where a.user_id=(select auth.uid())))
with check(exists(select 1 from public.qp_age_declarations a where a.user_id=(select auth.uid())));
drop policy if exists qp_adults_join on public.pinta_participants;
create policy qp_adults_join on public.pinta_participants as restrictive for insert to authenticated
with check(exists(select 1 from public.qp_age_declarations a where a.user_id=(select auth.uid())));
drop policy if exists qp_adults_change_membership on public.pinta_participants;
create policy qp_adults_change_membership on public.pinta_participants as restrictive for update to authenticated
using(exists(select 1 from public.qp_age_declarations a where a.user_id=(select auth.uid())))
with check(exists(select 1 from public.qp_age_declarations a where a.user_id=(select auth.uid())));
drop policy if exists qp_adults_read_chat on public.qp_messages;
create policy qp_adults_read_chat on public.qp_messages as restrictive for select to authenticated
using(exists(select 1 from public.qp_age_declarations a where a.user_id=(select auth.uid())));
drop policy if exists qp_adults_send_chat on public.qp_messages;
create policy qp_adults_send_chat on public.qp_messages as restrictive for insert to authenticated
with check(exists(select 1 from public.qp_age_declarations a where a.user_id=(select auth.uid())));

create or replace function qp_private.validate_plan_zone()
returns trigger language plpgsql security invoker set search_path='' as $fn$
begin
  if not exists(select 1 from pg_catalog.pg_timezone_names where name=new.qp_timezone) then
    raise exception 'La zona horaria del encuentro no es válida.';
  end if;
  return new;
end $fn$;
revoke all on function qp_private.validate_plan_zone() from public,anon,authenticated;
drop trigger if exists qp_validate_plan_zone on public.pinta_plans;
create trigger qp_validate_plan_zone before insert or update of qp_timezone on public.pinta_plans
for each row execute function qp_private.validate_plan_zone();

-- Solo administración puede cambiar proveedores; los clientes únicamente leen.
create table if not exists public.qp_app_config(key text primary key,value jsonb not null);
alter table public.qp_app_config enable row level security;
revoke all on public.qp_app_config from public,anon,authenticated;
grant select on public.qp_app_config to anon,authenticated;
drop policy if exists qp_config_read on public.qp_app_config;
create policy qp_config_read on public.qp_app_config for select to anon,authenticated using(true);
insert into public.qp_app_config(key,value) values('maps','{"tiles":"https://tile.openstreetmap.org/{z}/{x}/{y}.png","search":"https://photon.komoot.io/api/"}') on conflict(key) do nothing;

insert into public.qp_app_config(key,value) values('release','{"version":3,"adultDeclaration":true}') on conflict(key) do update set value=excluded.value;

-- Mantiene los privilegios previos de los planes; habilita las columnas nuevas.
grant select(qp_country_code,qp_city,qp_timezone,qp_latitude,qp_longitude,qp_cost,qp_currency) on public.pinta_plans to anon,authenticated;
grant insert(qp_country_code,qp_city,qp_timezone,qp_latitude,qp_longitude,qp_cost,qp_currency),update(qp_country_code,qp_city,qp_timezone,qp_latitude,qp_longitude,qp_cost,qp_currency) on public.pinta_plans to authenticated;
notify pgrst,'reload schema';
commit;

select c.relname as tabla,c.relrowsecurity as rls
from pg_class c join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public' and c.relname in ('pinta_plans','pinta_participants','qp_profiles','qp_messages','qp_age_declarations','qp_app_config');
