-- ONLY for the disposable GitHub Actions database qp_fixture. No real accounts.
do $$ begin if current_database()<>'qp_fixture' then raise exception 'Solo se permite la base de prueba qp_fixture'; end if; end $$;
create role anon nologin;
create role authenticated nologin;
create role supabase_auth_admin nologin;
create schema auth;
create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
grant usage on schema auth to anon,authenticated,supabase_auth_admin;
grant execute on function auth.uid() to anon,authenticated;
create table auth.users(id uuid primary key,raw_user_meta_data jsonb not null default '{}');
grant all on auth.users to supabase_auth_admin;
create table public.pinta_plans(
 id uuid primary key default gen_random_uuid(),owner_id uuid not null references auth.users(id),owner_name text not null,
 title text not null,category text not null,neighborhood text not null check(neighborhood in ('Palermo','Parque Rodó','Pocitos','Centro')),
 meeting_point text not null,starts_at timestamptz not null,capacity integer not null check(capacity between 2 and 30),description text not null
);
create table public.pinta_participants(
 plan_id uuid not null references public.pinta_plans(id) on delete cascade,user_id uuid not null references auth.users(id),
 display_name text not null,seat integer not null check(seat>=2),primary key(plan_id,user_id),unique(plan_id,seat)
);
alter table public.pinta_plans enable row level security;
alter table public.pinta_participants enable row level security;
grant select on public.pinta_plans,public.pinta_participants to anon,authenticated;
grant insert,update,delete on public.pinta_plans,public.pinta_participants to authenticated;
create policy fixture_plan_read on public.pinta_plans for select using(true);
create policy fixture_plan_insert on public.pinta_plans for insert to authenticated with check(owner_id=auth.uid());
create policy fixture_plan_update on public.pinta_plans for update to authenticated using(owner_id=auth.uid()) with check(owner_id=auth.uid());
create policy fixture_plan_delete on public.pinta_plans for delete to authenticated using(owner_id=auth.uid());
create policy fixture_member_read on public.pinta_participants for select using(true);
create policy fixture_member_insert on public.pinta_participants for insert to authenticated with check(user_id=auth.uid());
create policy fixture_member_delete on public.pinta_participants for delete to authenticated using(user_id=auth.uid());
insert into auth.users(id) values('00000000-0000-0000-0000-000000000001'),('00000000-0000-0000-0000-000000000002');
insert into public.pinta_plans(id,owner_id,owner_name,title,category,neighborhood,meeting_point,starts_at,capacity,description)
values('11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-000000000001','Fixture','Plan anterior','Paseos','Centro','Plaza',now()+interval '2 days',6,'Dato previo a la actualización');
