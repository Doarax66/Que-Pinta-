\set ON_ERROR_STOP on
do $$ begin if current_database()<>'qp_fixture' then raise exception 'Solo base de prueba';end if;end $$;
-- This suite follows the existing v3 checks: host=1, member=3, outsider=2.
select set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',false);
set role authenticated;
-- Online plans contain no country, city, pin or currency.
insert into public.pinta_plans(id,owner_id,owner_name,title,category,neighborhood,meeting_point,starts_at,capacity,description,qp_mode,qp_country_code,qp_city,qp_timezone,qp_cost,qp_currency,qp_platform)
values('33333333-3333-3333-3333-333333333333',auth.uid(),'Ana','Minecraft','Juegos','Online','Chat del grupo',now()+interval '1 day',6,'Jugamos juntos','online',null,null,'America/Montevideo',0,null,'PC');
do $$ declare denied boolean:=false;begin
 begin update public.pinta_plans set qp_finished_at=now() where id='33333333-3333-3333-3333-333333333333';
 exception when raise_exception then denied:=true;end;
 if not denied then raise exception 'Finalización antes de comenzar';end if;
end $$;
-- Finish a started physical plan without deleting its membership/chat.
update public.pinta_plans set starts_at=now()-interval '6 hours' where id='22222222-2222-2222-2222-222222222222';
reset role;
select set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000003',false);
set role authenticated;
do $$ declare changed integer;begin
 update public.pinta_plans set qp_finished_at=now() where id='22222222-2222-2222-2222-222222222222';get diagnostics changed=row_count;
 if changed<>0 then raise exception 'Un participante pudo finalizar el plan';end if;
end $$;
reset role;
select set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',false);
set role authenticated;
update public.pinta_plans set qp_finished_at=now() where id='22222222-2222-2222-2222-222222222222';
insert into public.qp_plan_reviews(plan_id,author_id,rating,comment) values('22222222-2222-2222-2222-222222222222',auth.uid(),3,'Un buen encuentro');
do $$ declare denied boolean:=false;begin
 begin delete from public.pinta_plans where id='22222222-2222-2222-2222-222222222222';exception when raise_exception then denied:=true;end;
 if not denied then raise exception 'Se borró el historial finalizado';end if;
end $$;
insert into public.qp_friendships(sender_id,receiver_id) values(auth.uid(),'00000000-0000-0000-0000-000000000003');
do $$ declare changed integer;begin
 update public.qp_friendships set status='accepted' where sender_id=auth.uid();get diagnostics changed=row_count;
 if changed<>0 then raise exception 'El emisor aceptó su propia solicitud';end if;
end $$;
do $$ declare denied boolean:=false;begin
 begin insert into public.qp_friendships(sender_id,receiver_id) values(auth.uid(),'00000000-0000-0000-0000-000000000002');exception when insufficient_privilege then denied:=true;end;
 if not denied then raise exception 'Solicitud a alguien sin plan compartido';end if;
end $$;
reset role;
select set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000003',false);
set role authenticated;
do $$ declare denied boolean:=false;begin
 if (select count(*) from public.qp_plan_reviews)<>1 then raise exception 'El grupo no ve la valoración';end if;
 begin insert into public.qp_plan_reviews(plan_id,author_id,rating) values('33333333-3333-3333-3333-333333333333',auth.uid(),1);exception when insufficient_privilege then denied:=true;end;
 if not denied then raise exception 'Valoró alguien que no es organizador';end if;
end $$;
do $$ declare denied boolean:=false;begin
 begin delete from public.pinta_participants where plan_id='22222222-2222-2222-2222-222222222222' and user_id=auth.uid();exception when raise_exception then denied:=true;end;
 if not denied then raise exception 'Se perdió un participante histórico';end if;
end $$;
do $$ declare denied boolean:=false;begin
 begin insert into public.qp_friendships(sender_id,receiver_id) values(auth.uid(),'00000000-0000-0000-0000-000000000001');exception when unique_violation then denied:=true;end;
 if not denied then raise exception 'Se duplicó la solicitud inversa';end if;
end $$;
update public.qp_friendships set status='accepted' where receiver_id=auth.uid();
do $$ begin if not exists(select 1 from public.qp_friendships where status='accepted') then raise exception 'No se pudo aceptar';end if;end $$;
reset role;
select set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000002',false);
set role authenticated;
do $$ begin
 if exists(select 1 from public.qp_friendships) then raise exception 'Amistades visibles a terceros';end if;
 if exists(select 1 from public.qp_plan_reviews) then raise exception 'Valoración visible fuera del grupo';end if;
end $$;
reset role;
set role anon;
do $$ declare denied boolean:=false;begin
 begin perform id from public.qp_friendships;exception when insufficient_privilege then denied:=true;end;
 if not denied then raise exception 'Amistades públicas';end if;
end $$;
reset role;
select 'OK: online, finalización manual, historial, valoración privada y amistad mutua' as resultado;
