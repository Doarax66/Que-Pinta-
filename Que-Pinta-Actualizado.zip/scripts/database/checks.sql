\set ON_ERROR_STOP on
do $$ begin if current_database()<>'qp_fixture' then raise exception 'Solo se permite la base de prueba qp_fixture'; end if; end $$;
-- The installer was run twice. Accounts and the legacy plan must still exist.
do $$ begin
 if (select count(*) from auth.users)<>2 then raise exception 'Cuentas anteriores modificadas'; end if;
 if not exists(select 1 from public.pinta_plans where id='11111111-1111-1111-1111-111111111111' and qp_country_code='UY' and qp_city='Montevideo') then raise exception 'Plan anterior perdido'; end if;
end $$;
set role anon;
select key from public.qp_app_config where key='release';
do $$ declare denied boolean:=false; begin
 begin perform user_id from public.qp_age_declarations; exception when insufficient_privilege then denied:=true; end;
 if not denied then raise exception 'Anon puede leer las declaraciones de edad'; end if;
end $$;
reset role;
select set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',false);
set role authenticated;
-- Existing account cannot publish without declaring age.
do $$ declare denied boolean:=false; begin
 begin
 insert into public.pinta_plans(owner_id,owner_name,title,category,neighborhood,meeting_point,starts_at,capacity,description)
 values(auth.uid(),'Ana','Test','Paseos','Centro','Plaza',now()+interval '1 day',6,'Test');
 exception when insufficient_privilege then denied:=true; end;
 if not denied then raise exception 'Se permitió publicar sin declaración de edad'; end if;
end $$;
-- The database rejects an under-18 declaration even if the client is bypassed.
do $$ declare denied boolean:=false; begin
 begin insert into public.qp_age_declarations(user_id,birth_date) values(auth.uid(),current_date-interval '10 years');
 exception when raise_exception then
   if sqlerrm not like '%18 años%' then raise; end if; denied:=true;
 end;
 if not denied then raise exception 'Se aceptó una declaración de menor de edad'; end if;
end $$;
insert into public.qp_age_declarations(user_id,birth_date) values(auth.uid(),date '2000-01-01');
-- Cannot forge a declaration belonging to another account.
do $$ declare denied boolean:=false; begin
 begin insert into public.qp_age_declarations(user_id,birth_date) values('00000000-0000-0000-0000-000000000002',date '2000-01-01');
 exception when insufficient_privilege then denied:=true; end;
 if not denied then raise exception 'Se aceptó una fecha para otro usuario'; end if;
end $$;
insert into public.pinta_plans(id,owner_id,owner_name,title,category,neighborhood,meeting_point,starts_at,capacity,description,qp_country_code,qp_city,qp_timezone,qp_latitude,qp_longitude,qp_cost,qp_currency)
 values('22222222-2222-2222-2222-222222222222',auth.uid(),'Ana','Paseo Madrid','Paseos','Retiro','Parque',now()+interval '1 day',6,'Test','ES','Madrid','Europe/Madrid',40.415,-3.684,12.50,'EUR');
-- Partial coordinates must fail instead of silently losing the meeting point.
do $$ declare denied boolean:=false; begin
 begin update public.pinta_plans set qp_longitude=null where id='22222222-2222-2222-2222-222222222222';
 exception when check_violation then denied:=true; end;
 if not denied then raise exception 'Se guardó un pin incompleto'; end if;
end $$;
insert into public.qp_messages(plan_id,user_id,display_name,body) values('22222222-2222-2222-2222-222222222222',auth.uid(),'Ana','Hola');
reset role;
-- Supabase Auth's unprivileged role can create an adult account and its declaration.
set role supabase_auth_admin;
insert into auth.users(id,raw_user_meta_data) values('00000000-0000-0000-0000-000000000003','{"display_name":"Nueva","birth_date":"2000-01-01"}');
do $$ declare denied boolean:=false; begin
 begin insert into auth.users(id,raw_user_meta_data) values('00000000-0000-0000-0000-000000000004',jsonb_build_object('birth_date',(current_date-interval '10 years')::date));
 exception when raise_exception then
  if sqlerrm not like '%18 años%' then raise; end if; denied:=true;
 end;
 if not denied then raise exception 'Se registró un menor declarado'; end if;
end $$;
reset role;
select set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000003',false);
set role authenticated;
do $$ begin
 if (select count(user_id) from public.qp_age_declarations)<>1 then raise exception 'No se aísla la declaración de edad por usuario'; end if;
 if exists(select 1 from public.qp_messages) then raise exception 'Un extraño puede leer el chat'; end if;
end $$;
insert into public.pinta_participants(plan_id,user_id,display_name,seat) values('22222222-2222-2222-2222-222222222222',auth.uid(),'Nueva',2);
do $$ begin if (select count(*) from public.qp_messages)<>1 then raise exception 'El miembro no puede ver su chat'; end if; end $$;
insert into public.qp_messages(plan_id,user_id,display_name,body) values('22222222-2222-2222-2222-222222222222',auth.uid(),'Nueva','Hola al grupo');
-- Birth dates are never granted to the public-profile endpoint, even for the owner.
do $$ declare denied boolean:=false; begin
 begin perform birth_date from public.qp_age_declarations; exception when insufficient_privilege then denied:=true; end;
 if not denied then raise exception 'La API puede leer fechas de nacimiento'; end if;
end $$;
reset role;
select 'OK: actualización idempotente, datos conservados, registro, edad, mapas, países y chat con RLS' as resultado;
