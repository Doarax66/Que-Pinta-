// Isolated application-flow checks. Fake DOM / fake transport; no production calls.
'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'index.html'),'utf8');
class Element{
 constructor(){this.value='';this.innerHTML='';this.textContent='';this.hidden=false;this.disabled=false;this.open=false;this.dataset={};this.children=[];this.style={setProperty(){}};this.classList={add(){},remove(){}};this.listeners={};}
 setAttribute(k,v){this[k]=String(v);}removeAttribute(k){delete this[k];}addEventListener(k,f){this.listeners[k]=f;}
 querySelector(){return new Element();}querySelectorAll(){return [];}showModal(){this.open=true;}close(){this.open=false;this.listeners.close?.();}focus(){}select(){}reset(){}appendChild(e){this.children.push(e);}append(e){this.children.push(e);}replaceChildren(){this.children=[];}animate(){}
}
const nodes=Object.fromEntries([...html.matchAll(/\bid="([^"]+)"/g)].map(m=>[m[1],new Element()]));
const actor={id:'00000000-0000-0000-0000-000000000001',email:'fixture@example.test',user_metadata:{display_name:'Ana'}};
let session=actor,ageRows=[],records=[],calls=[],profileWrites=[],lastSignup=null,reviews=[],friendRows=[];
const fakeDB={auth:{onAuthStateChange(){},getSession:async()=>({data:{session:session?{user:session}:null}}),signUp:async payload=>{lastSignup=payload;return {data:{session:null}};},updateUser:async({data})=>({data:{user:{...actor,user_metadata:data}}})},from(table){
 let op='select',payload,filters=[],conditions=[],singular=false,capability=false;
 const q={select(){return q;},order(){return q;},limit(n){capability=n===0;return q;},eq(k,v){filters.push([k,v]);return q;},in(){return q;},gte(k,v){conditions.push(r=>r[k]>=v);return q;},is(k,v){conditions.push(r=>r[k]==null);return q;},not(k,op,v){conditions.push(r=>r[k]!=null);return q;},lt(){return q;},or(){return q;},range(){return q;},single(){singular=true;return q;},maybeSingle(){singular=true;return q;},insert(v){op='insert';payload=v;return q;},update(v){op='update';payload=v;return q;},upsert(v){op='upsert';payload=v;return q;},delete(){op='delete';return q;},then(resolve,reject){return Promise.resolve().then(()=>{
  calls.push({table,op,payload});if(capability)return {data:[],error:null};
  let data=[];
  if(op==='insert'&&table==='pinta_plans'){records.push({...payload,id:'test-plan-'+(records.length+1),pinta_participants:[]});return {data:{id:records.at(-1).id}};}
  if(op==='insert'&&table==='qp_age_declarations'){ageRows.push(payload);return {data:null};}
  if(op==='upsert'&&table==='qp_profiles'){profileWrites.push(payload);return {data:null};}
  if(op==='insert'&&table==='qp_friendships'){friendRows.push({...payload,id:'friend-1',status:'pending'});return {data:null};}
  if(table==='qp_friendships')data=friendRows;
  if(op==='insert'&&table==='qp_plan_reviews'){reviews.push(payload);return {data:null};}
  if(table==='qp_plan_reviews')data=reviews;
  if(table==='qp_app_config')data=[{key:'release',value:{version:3,adultDeclaration:true}}];
  if(table==='pinta_plans')data=records;
  if(table==='qp_age_declarations')data=ageRows;
  data=data.filter(row=>conditions.every(f=>f(row))&&filters.every(([k,v])=>String(row[k])===String(v)));
  if(op==='update')data.forEach(row=>Object.assign(row,payload));
  return {data:singular?(data[0]||null):data,error:null};
 }).then(resolve,reject);}};return q;}};
const documentEvents=[];
const document={getElementById:id=>nodes[id],querySelectorAll:()=>[],querySelector:()=>null,addEventListener(type,handler){documentEvents.push([type,handler]);},createElement:()=>new Element(),hidden:false};
const context={console,URL,Intl,Date,Set,Map,JSON,Number,String,Array,Promise,Error,Math,Boolean,RegExp,document,location:{href:'https://example.test/'},navigator:{},matchMedia:()=>({matches:true}),localStorage:{getItem:()=>null,setItem(){}},setTimeout:(f)=>{if(!String(f).includes('toast'))return 1;return 1;},clearTimeout(){},setInterval(){},clearInterval(){},addEventListener(){},supabase:{createClient:()=>fakeDB},PintaMaps:{configure(){},create:()=>null},crypto:require('node:crypto').webcrypto};
context.window=context;vm.createContext(context);
for(const file of ['core.js','geo.js','app.js'])vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),context,{filename:file});
const run=source=>vm.runInContext(source,context),tick=()=>new Promise(r=>setImmediate(r));
(async()=>{
 for(let i=0;i<8;i++)await tick();
 assert(run('capabilities.v3 && capabilities.age'));assert.equal(run('user.id'),actor.id);
 // Age declaration blocks participation until a valid birthday is submitted.
 assert.equal(await run('ensureAdult({create:true})'),false);assert(nodes.age.open);
 nodes['age-birthdate'].value='2015-09-12';await nodes['age-form'].onsubmit({preventDefault(){}});assert.equal(ageRows.length,0);assert.match(nodes['age-error'].textContent,/18/);
 nodes['age-birthdate'].value='2000-06-17';await nodes['age-form'].onsubmit({preventDefault(){}});assert.equal(ageRows.length,1);assert.equal(await run('ensureAdult()'),true);
 console.log('OK existing account: private adult declaration before participation');
 // Post a Madrid meetup and ensure geographic metadata and pin share one write.
 for(const [id,value] of Object.entries({'plan-mode':'presential','plan-country':'ES','plan-city':'Madrid','plan-timezone':'Europe/Madrid','date':'2030-07-15T19:00','capacity':'6','host-name':'Ana','title':'Paseo','category':'Paseos','neighborhood':'Retiro','place':'Entrada del parque','description':'Una vuelta juntos','cost':'12.50','currency':'EUR'}))nodes[id].value=value;
 nodes['has-cost'].checked=true;run('setMeetingPin(40.415,-3.684)');await nodes.form.onsubmit({preventDefault(){},target:nodes.form});
 assert.equal(nodes['create-error'].textContent,'');assert.equal(records.length,1);assert.equal(records[0].qp_city,'Madrid');assert.equal(records[0].starts_at,'2030-07-15T17:00:00.000Z');assert.equal(records[0].qp_cost,12.5);assert.equal(records[0].qp_latitude,40.415);assert.equal(calls.filter(c=>c.table==='pinta_plans'&&c.op==='insert').length,1);assert.equal(calls.filter(c=>c.table==='qp_plan_details'&&c.op==='insert').length,0);
 console.log('OK one write saves plan, country, local time, map point and currency');
 // Online mode ignores physical form values and uses the device timezone.
 nodes['plan-mode'].value='online';nodes.category.value='Juegos';nodes.platform.value='PC';nodes['server-region'].value='Sudamérica';nodes.title.value='Minecraft';nodes.date.value='2030-07-16T19:00';nodes['plan-country'].value='';nodes['plan-city'].value='';nodes.place.value='';nodes.description.value='';
 run('syncPlanMode()');assert(nodes['physical-fields'].hidden);assert.equal(nodes['plan-city'].required,false);assert(nodes['cost-field'].hidden);
 await nodes.form.onsubmit({preventDefault(){},target:nodes.form});assert.equal(nodes['create-error'].textContent,'');assert.equal(records.length,2);
 const remote=records[1];assert.equal(remote.qp_mode,'online');assert.equal(remote.qp_country_code,null);assert.equal(remote.qp_city,null);assert.equal(remote.qp_currency,null);assert.equal(remote.qp_cost,0);assert.equal(remote.qp_latitude,null);assert.equal(remote.qp_platform,'PC');assert.equal(remote.qp_timezone,run('deviceZone()'));
 run("countryFilter='VE';cityFilter='Caracas';view='explore';resetFilters()");await run('loadPlans()');assert.equal(run('plans.length'),1);assert.equal(run('plans[0].qp_mode'),'online');
 console.log('OK online plan has no physical location and appears across countries');
 // An ongoing meeting remains in My plans even six hours after its start.
 records[0].starts_at=new Date(Date.now()-6*3600000).toISOString();
 run("view='mine';historyMode='active';resetFilters()");await run('loadPlans()');assert.equal(run('plans.length'),2);
 await run("showPlan('test-plan-1')");assert.equal(nodes['finish-plan'].hidden,false);
 run('openFinish(selectedPlan)');nodes['plan-rating'].value='3';nodes['rating-comment'].value='Muy buen paseo';
 await nodes['finish-form'].onsubmit({preventDefault(){}});assert.equal(nodes['finish-error'].textContent,'');assert(records[0].qp_finished_at);assert.equal(reviews.length,1);assert.equal(reviews[0].rating,3);assert.equal(run('historyMode'),'past');assert.equal(run('plans.length'),1);assert.equal(run('plans[0].id'),'test-plan-1');assert.equal(nodes.join.disabled,true);
 run("view='explore';countryFilter='ES';cityFilter='Madrid'");await run('loadPlans()');assert.equal(run('plans.length'),1);assert.equal(run('plans[0].id'),'test-plan-2');
 console.log('OK six-hour plan stays active until the organizer finishes, then moves to history');
 for(const [country,currency] of [['UY','UYU'],['ES','EUR'],['VE','VES'],['JP','JPY'],['BG','EUR']]){nodes['plan-mode'].value='presential';nodes['plan-country'].value=country;run('populateTimezones()');assert.equal(nodes.currency.value,currency);}
 console.log('OK currency follows the plan country without a currency selector');
 // Mutual-friendship UI: sender sends a request; recipient explicitly accepts.
 const friendHandler=documentEvents.find(([t,f])=>t==='click'&&String(f).includes('[data-friend-send]'))[1];
 const sendButton={disabled:false,dataset:{friendSend:'00000000-0000-0000-0000-000000000003'}};
 await friendHandler({target:{closest:()=>sendButton}});assert.equal(friendRows.length,1);assert.equal(friendRows[0].status,'pending');assert.equal(friendRows[0].sender_id,actor.id);
 run("user={id:'00000000-0000-0000-0000-000000000003',user_metadata:{display_name:'Nueva'}}");
 const acceptButton={disabled:false,dataset:{friendAccept:'friend-1'}};await friendHandler({target:{closest:()=>acceptButton}});assert.equal(friendRows[0].status,'accepted');
 assert(run("friendButtons({id:'friend-1',status:'accepted'},'other').includes('Ya son amigos')"));
 run("user={id:'00000000-0000-0000-0000-000000000001',user_metadata:{display_name:'Ana'}}");
 console.log('OK request remains pending until the recipient accepts in the UI');
 // Public social links respect the visibility choice; dates never enter profiles.
 for(const [id,value] of Object.entries({'profile-name':'Ana','profile-bio':'Hola','profile-photo':'','profile-instagram':'@ana','profile-facebook':'https://www.facebook.com/ana'}))nodes[id].value=value;
 nodes['show-socials'].checked=false;await nodes['profile-form'].onsubmit({preventDefault(){}});assert.equal(profileWrites.at(-1).instagram_url,'');assert.equal(profileWrites.at(-1).facebook_url,'');assert(!('birth_date' in profileWrites.at(-1)));
 nodes['show-socials'].checked=true;await nodes['profile-form'].onsubmit({preventDefault(){}});assert.equal(profileWrites.at(-1).instagram_url,'https://www.instagram.com/ana');assert.equal(profileWrites.at(-1).facebook_url,'https://www.facebook.com/ana');
 console.log('OK social visibility is enforced in the public profile payload');
 // A signed-out visitor can register; no private age-table access is needed for capability detection.
 session=null;run('user=null');await run('detectCapabilities()');assert(run('capabilities.age'));
 run("openAuth('signup')");nodes['auth-name'].value='Nueva';nodes['auth-email'].value='new@example.test';nodes['auth-password'].value='test-only-password';nodes['auth-birthdate'].value='2015-01-01';
 await nodes['auth-form'].onsubmit({preventDefault(){}});assert.equal(lastSignup,null);
 nodes['auth-birthdate'].value='2000-01-01';await nodes['auth-form'].onsubmit({preventDefault(){}});assert.equal(lastSignup.options.data.birth_date,'2000-01-01');
 console.log('OK signup rejects declared minors and submits a private birthday for adults');
 // Graceful map fallback still produces directions using the meeting text.
 run("showMeetingMap({meeting_point:'Parque & plaza',neighborhood:'Centro',qp_city:'Madrid',qp_country_code:'ES'})");assert(nodes['detail-map-section'].hidden);assert(nodes.directions.href.includes('destination='));assert(!nodes.directions.href.includes('& plaza'));
 console.log('OK plans without a map pin retain an encoded directions link');
 console.log('9 isolated application flows passed (fake DOM and API; no browser or live database).');
})().catch(e=>{console.error(e);process.exitCode=1;});
