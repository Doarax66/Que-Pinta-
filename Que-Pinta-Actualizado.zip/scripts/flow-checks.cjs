// Isolated application-flow checks. Fake DOM / fake transport; no production calls.
'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'index.html'),'utf8');
class Element{
 constructor(){this.value='';this.innerHTML='';this.textContent='';this.hidden=false;this.disabled=false;this.open=false;this.dataset={};this.children=[];this.style={setProperty(){}};this.classList={add(){},remove(){}};this.listeners={};}
 setAttribute(k,v){this[k]=String(v);}removeAttribute(k){delete this[k];}addEventListener(k,f){this.listeners[k]=f;}
 querySelector(){return new Element();}querySelectorAll(){return [];}showModal(){this.open=true;}close(){this.open=false;this.listeners.close?.();}focus(){}select(){}reset(){}appendChild(e){this.children.push(e);}append(e){this.children.push(e);}replaceChildren(){this.children=[];}animate(){}
}
const nodes=Object.fromEntries([...html.matchAll(/\bid="([^"]+)"/g)].map(m=>[m[1],new Element()]));
const actor={id:'00000000-0000-0000-0000-000000000001',email:'fixture@example.test',user_metadata:{display_name:'Ana'}};
let session=actor,ageRows=[],records=[],calls=[],profileWrites=[],lastSignup=null;
const fakeDB={auth:{onAuthStateChange(){},getSession:async()=>({data:{session:session?{user:session}:null}}),signUp:async payload=>{lastSignup=payload;return {data:{session:null}};},updateUser:async({data})=>({data:{user:{...actor,user_metadata:data}}})},from(table){
 let op='select',payload,filters=[],singular=false,capability=false;
 const q={select(){return q;},order(){return q;},limit(n){capability=n===0;return q;},eq(k,v){filters.push([k,v]);return q;},in(){return q;},gte(){return q;},lt(){return q;},or(){return q;},range(){return q;},single(){singular=true;return q;},maybeSingle(){singular=true;return q;},insert(v){op='insert';payload=v;return q;},upsert(v){op='upsert';payload=v;return q;},delete(){op='delete';return q;},then(resolve,reject){return Promise.resolve().then(()=>{
  calls.push({table,op,payload});if(capability)return {data:[],error:null};
  let data=[];
  if(op==='insert'&&table==='pinta_plans'){records.push({...payload,id:'test-plan',pinta_participants:[]});return {data:{id:'test-plan'}};}
  if(op==='insert'&&table==='qp_age_declarations'){ageRows.push(payload);return {data:null};}
  if(op==='upsert'&&table==='qp_profiles'){profileWrites.push(payload);return {data:null};}
  if(table==='qp_app_config')data=[{key:'release',value:{version:3,adultDeclaration:true}}];
  if(table==='pinta_plans')data=records;
  if(table==='qp_age_declarations')data=ageRows;
  data=data.filter(row=>filters.every(([k,v])=>String(row[k])===String(v)));
  return {data:singular?(data[0]||null):data,error:null};
 }).then(resolve,reject);}};return q;}};
const document={getElementById:id=>nodes[id],querySelectorAll:()=>[],querySelector:()=>null,addEventListener(){},createElement:()=>new Element(),hidden:false};
const context={console,URL,Intl,Date,Set,Map,JSON,Number,String,Array,Promise,Error,Math,Boolean,RegExp,document,location:{href:'https://example.test/'},navigator:{},matchMedia:()=>({matches:true}),localStorage:{getItem:()=>null,setItem(){}},setTimeout:(f)=>{if(!String(f).includes('toast'))return 1;return 1;},clearTimeout(){},setInterval(){},clearInterval(){},addEventListener(){},supabase:{createClient:()=>fakeDB},PintaMaps:{configure(){},create:()=>null},crypto:require('node:crypto').webcrypto};
context.window=context;vm.createContext(context);
for(const file of ['core.js','geo.js','app.js'])vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),context,{filename:file});
const run=source=>vm.runInContext(source,context),tick=()=>new Promise(r=>setImmediate(r));
(async()=>{
 for(let i=0;i<8;i++)await tick();
 assert(run('capabilities.v3 && capabilities.age'));assert.equal(run('user.id'),actor.id);
 // Age declaration blocks participation until a valid birthday is submitted.
 assert.equal(await run('ensureAdult({create:true})'),false);assert(nodes.age.open);
 nodes['age-birthdate'].value='2015-09-12';await nodes['age-form'].onsubmit({preventDefault(){}});assert.equal(ageRows.length,0);assert.match(nodes['age-error'].textContent,/18/);
 nodes['age-birthdate'].value='2000-06-17';await nodes['age-form'].onsubmit({preventDefault(){}});assert.equal(ageRows.length,1);assert.equal(await run('ensureAdult()'),true);
 console.log('OK existing account: private adult declaration before participation');
 // Post a Madrid meetup and ensure geographic metadata and pin share one write.
 for(const [id,value] of Object.entries({'plan-country':'ES','plan-city':'Madrid','plan-timezone':'Europe/Madrid','date':'2030-07-15T19:00','capacity':'6','host-name':'Ana','title':'Paseo','category':'Paseos','neighborhood':'Retiro','place':'Entrada del parque','description':'Una vuelta juntos','cost':'12.50','currency':'EUR'}))nodes[id].value=value;
 run('setMeetingPin(40.415,-3.684)');await nodes.form.onsubmit({preventDefault(){},target:nodes.form});
 assert.equal(nodes['create-error'].textContent,'');assert.equal(records.length,1);assert.equal(records[0].qp_city,'Madrid');assert.equal(records[0].starts_at,'2030-07-15T17:00:00.000Z');assert.equal(records[0].qp_cost,12.5);assert.equal(records[0].qp_latitude,40.415);assert.equal(calls.filter(c=>c.table==='pinta_plans'&&c.op==='insert').length,1);assert.equal(calls.filter(c=>c.table==='qp_plan_details'&&c.op==='insert').length,0);
 console.log('OK one write saves plan, country, local time, map point and currency');
 // Public social links respect the visibility choice; dates never enter profiles.
 for(const [id,value] of Object.entries({'profile-name':'Ana','profile-bio':'Hola','profile-photo':'','profile-instagram':'@ana','profile-facebook':'https://www.facebook.com/ana'}))nodes[id].value=value;
 nodes['show-socials'].checked=false;await nodes['profile-form'].onsubmit({preventDefault(){}});assert.equal(profileWrites.at(-1).instagram_url,'');assert.equal(profileWrites.at(-1).facebook_url,'');assert(!('birth_date' in profileWrites.at(-1)));
 nodes['show-socials'].checked=true;await nodes['profile-form'].onsubmit({preventDefault(){}});assert.equal(profileWrites.at(-1).instagram_url,'https://www.instagram.com/ana');assert.equal(profileWrites.at(-1).facebook_url,'https://www.facebook.com/ana');
 console.log('OK social visibility is enforced in the public profile payload');
 // A signed-out visitor can register; no private age-table access is needed for capability detection.
 session=null;run('user=null');await run('detectCapabilities()');assert(run('capabilities.age'));
 run("openAuth('signup')");nodes['auth-name'].value='Nueva';nodes['auth-email'].value='new@example.test';nodes['auth-password'].value='test-only-password';nodes['auth-birthdate'].value='2015-01-01';
 await nodes['auth-form'].onsubmit({preventDefault(){}});assert.equal(lastSignup,null);
 nodes['auth-birthdate'].value='2000-01-01';await nodes['auth-form'].onsubmit({preventDefault(){}});assert.equal(lastSignup.options.data.birth_date,'2000-01-01');
 console.log('OK signup rejects declared minors and submits a private birthday for adults');
 // Graceful map fallback still produces directions using the meeting text.
 run("showMeetingMap({meeting_point:'Parque & plaza',neighborhood:'Centro',qp_city:'Madrid',qp_country_code:'ES'})");assert(nodes['detail-map-section'].hidden);assert(nodes.directions.href.includes('destination='));assert(!nodes.directions.href.includes('& plaza'));
 console.log('OK plans without a map pin retain an encoded directions link');
 console.log('5 isolated application flows passed (fake DOM and API; no browser or live database).');
})().catch(e=>{console.error(e);process.exitCode=1;});
