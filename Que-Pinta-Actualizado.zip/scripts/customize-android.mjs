// Runs automatically after cap sync, including the already installed ZIP workflow.
import {readFile,writeFile,cp} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const android=resolve(root,'mobile/android');
await cp(resolve(root,'mobile/android-res'),resolve(android,'app/src/main/res'),{recursive:true});
const manifestPath=resolve(android,'app/src/main/AndroidManifest.xml');
let manifest=await readFile(manifestPath,'utf8');
for(const name of ['android.permission.ACCESS_COARSE_LOCATION','android.permission.ACCESS_FINE_LOCATION'])if(!manifest.includes(name))manifest=manifest.replace('</manifest>',`<uses-permission android:name="${name}" />\n</manifest>`);
await writeFile(manifestPath,manifest);
const stylesPath=resolve(android,'app/src/main/res/values/styles.xml');
let styles=await readFile(stylesPath,'utf8');
// Set system icon contrast without overlaying the application on status/navigation bars.
styles=styles.replace(/(<style name="AppTheme.NoActionBar"[^>]*>)([\s\S]*?)(<\/style>)/,(_,start,body,end)=>{
  for(const key of ['android:windowLightStatusBar','android:windowLightNavigationBar','android:statusBarColor','android:navigationBarColor','android:windowBackground'])body=body.replace(new RegExp('<item name="'+key+'">[\\s\\S]*?</item>','g'),'');
  return start+body+'\n<item name="android:windowLightStatusBar">true</item><item name="android:windowLightNavigationBar">true</item><item name="android:statusBarColor">#F4EDFF</item><item name="android:navigationBarColor">#F4EDFF</item><item name="android:windowBackground">#F4EDFF</item>\n'+end;
});
styles=styles.replace(/(<style name="AppTheme.NoActionBarLaunch"[^>]*>)[\s\S]*?(<\/style>)/,(_,start,end)=>start+'<item name="android:background">@color/qp_launcher_background</item><item name="windowSplashScreenBackground">@color/qp_launcher_background</item><item name="windowSplashScreenAnimatedIcon">@drawable/qp_launcher_foreground</item><item name="postSplashScreenTheme">@style/AppTheme.NoActionBar</item>'+end);
await writeFile(stylesPath,styles);
const gradlePath=resolve(android,'app/build.gradle');
let gradle=await readFile(gradlePath,'utf8');gradle=gradle.replace(/versionCode\s+\d+/,'versionCode 40000').replace(/versionName\s+"[^"]+"/,'versionName "4.0.0"');
await writeFile(gradlePath,gradle);
console.log('Que Pinta 3: icono, permisos solicitados al pulsar ubicación y apariencia Android preparados.');
