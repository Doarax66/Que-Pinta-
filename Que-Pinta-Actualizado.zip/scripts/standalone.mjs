// Produce a single HTML file for GitHub Pages uploads from a phone.
import { readFile,writeFile,mkdir } from 'node:fs/promises';
import { resolve,dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const destination=resolve(root,'dist');
let html=await readFile(resolve(root,'index.html'),'utf8');
const css=await readFile(resolve(root,'styles.css'),'utf8');
const core=await readFile(resolve(root,'core.js'),'utf8');
let app=await readFile(resolve(root,'app.js'),'utf8');
for(const name of ['deporte','comida','paseos']){
  const file='assets/'+name+'.webp';
  const data='data:image/webp;base64,'+(await readFile(resolve(root,file))).toString('base64');
  html=html.replaceAll(file,data);app=app.replaceAll(file,data);
}
const favicon='data:image/svg+xml;base64,'+(await readFile(resolve(root,'assets/icon.svg'))).toString('base64');
html=html.replaceAll('assets/icon.svg',favicon);
html=html.replace('<link rel="stylesheet" href="styles.css">',()=>'<style>'+css+'</style>');
// Inline deferred scripts don't actually defer. Wait for the Supabase CDN script.
const source=core+'\n'+app;
html=html.replace('<script src="core.js" defer></script>','').replace('<script src="app.js" defer></script>',()=>'<script>\ndocument.addEventListener("DOMContentLoaded",function(){\n'+source.replaceAll('</script','<\\/script')+'\n});\n</script>');
await mkdir(destination,{recursive:true});await writeFile(resolve(destination,'index.html'),html);
console.log('HTML independiente generado:',Buffer.byteLength(html),'bytes.');
