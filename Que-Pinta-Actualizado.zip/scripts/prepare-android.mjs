import { readFile, writeFile, mkdir, cp, access } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const www=resolve(root,'mobile/www');
const sdk=resolve(root,'mobile/node_modules/@supabase/supabase-js/dist/umd/supabase.js');
try{await access(sdk);}catch{throw Error('Primero instalá las dependencias: npm --prefix mobile install');}
await mkdir(www,{recursive:true});
let html=await readFile(resolve(root,'index.html'),'utf8');
html=html.replace('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.57.4/dist/umd/supabase.js','supabase.js');
await writeFile(resolve(www,'index.html'),html);
for(const name of ['styles.css','core.js','app.js','assets'])await cp(resolve(root,name),resolve(www,name),{recursive:true});
await cp(sdk,resolve(www,'supabase.js'));
console.log('Archivos de la app preparados en mobile/www.');
