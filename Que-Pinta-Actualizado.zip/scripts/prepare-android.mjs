import { readFile, writeFile, mkdir, cp, access } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const www=resolve(root,'mobile/www');
const sdk=resolve(root,'mobile/node_modules/@supabase/supabase-js/dist/umd/supabase.js');
try{await access(sdk);}catch{throw Error('Primero instala las dependencias: npm --prefix mobile install');}
await mkdir(www,{recursive:true});
let html=await readFile(resolve(root,'index.html'),'utf8');
html=html.replace('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.57.4/dist/umd/supabase.js','supabase.js');
html=html.replaceAll('https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/','leaflet/');
await cp(resolve(root,'mobile/node_modules/leaflet/dist'),resolve(www,'leaflet'),{recursive:true});
await writeFile(resolve(www,'index.html'),html);
for(const name of ['styles.css','core.js','geo.js','maps.js','app.js','assets'])await cp(resolve(root,name),resolve(www,name),{recursive:true});
await cp(sdk,resolve(www,'supabase.js'));
for(const [source,target] of [['leaflet/LICENSE','leaflet/LICENSE'],['@supabase/supabase-js/LICENSE','SUPABASE-LICENSE']]){try{await access(resolve(root,'mobile/node_modules',source));await cp(resolve(root,'mobile/node_modules',source),resolve(www,target));}catch{ /* Minified sources retain their copyright headers. */ }}
console.log('Archivos de la app preparados en mobile/www.');
