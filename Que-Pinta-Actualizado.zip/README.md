# Que Pinta 3.0 · Encuentra tu próximo plan

Actualización del proyecto Que Pinta para web y Android. Mantiene la conexión y la clave pública del proyecto Supabase existente, los nombres de sus tablas y el identificador Android `uy.quepinta.app`.

## Incluye

- Icono violeta de un pin sonriente, también instalado como icono adaptable y pantalla de inicio de Android.
- Fondo lila, cabecera morada, tarjetas con símbolos, transiciones, aparición de tarjetas, respuesta al tocar y celebración al publicar. Respeta la preferencia de reducir movimiento.
- Retirada de todas las fotografías generadas con IA de la distribución nueva. Las fotos opcionales de perfil siguen siendo enlaces proporcionados por la persona.
- Países y territorios del catálogo IANA; ciudad y barrio escritos libremente. Selector explícito de zona horaria del encuentro, necesario en países con varias zonas. No requiere residir en Montevideo.
- Búsqueda por país, ciudad, zona, actividad, texto, fecha, plazas y costo gratuito. Conserva los planes anteriores como Uruguay/Montevideo.
- Mapa interactivo con búsqueda de lugares, pin movible, coordenadas opcionales, ubicación del dispositivo solo al pulsar el botón y enlace para llegar al encuentro. También funciona la creación sin pin si se escribe el lugar.
- Costos informativos y selector de moneda. La ubicación, el pin y el costo se guardan en la misma inserción del plan.
- Enlaces opcionales a Instagram y Facebook. El perfil público recibe esos enlaces únicamente si se activa «Mostrar estos enlaces». No es inicio de sesión con esas redes.
- Fecha de nacimiento privada, bloqueo del registro si se declara menos de 18 años y comprobación en servidor antes de crear, unirse o conversar. Las cuentas anteriores completan su declaración al participar.
- Perfiles públicos y chat de los miembros del plan, activados por el instalador incluido. Conserva crear/cancelar, unirse/salir, compartir y guardar en el dispositivo.
- Español neutro y ajuste de márgenes de Android para evitar superposición con las barras del sistema.

La declaración de edad **no verifica la identidad ni prueba que la fecha sea verdadera**. No recoge documento, selfie ni biometría. No muestra una insignia de «identidad verificada».

## Actualizar desde el teléfono

1. Conserva una copia de la versión anterior. Descarga los archivos de esta entrega.
2. Sube **Que-Pinta-Actualizado.zip**, con ese nombre exacto, a la raíz de [tu repositorio](https://github.com/Doarax66/Que-Pinta-/upload/main), reemplazando el ZIP anterior. No necesitas descomprimirlo para subirlo. Si el teléfono añadió `(1)` al nombre, renómbralo antes.
3. Reemplaza el contenido de [.github/workflows/android.yml](https://github.com/Doarax66/Que-Pinta-/edit/main/.github/workflows/android.yml) con el archivo `android.yml` de esta entrega. La primera línea del contenido es `name: Crear APK de prueba`; no pegues el nombre del archivo ni las marcas de un bloque de código.
4. Abre [Actions](https://github.com/Doarax66/Que-Pinta-/actions/workflows/android.yml) y pulsa **Run workflow → main → Run workflow**. Este flujo valida el instalador sobre PostgreSQL 17 en una base desechable con datos ficticios antes de compilar. No se conecta a tu Supabase real.
5. Cuando la ejecución esté verde, copia TODO el contenido de `ACTIVAR-FUNCIONES.sql` en el [SQL Editor de tu proyecto](https://supabase.com/dashboard/project/duieibwtyxrqfzlhqbap/sql/new) y ejecútalo una vez. No cambies a otro proyecto. El archivo se ejecuta en una transacción y conserva las cuentas y los planes. Si aparece un error, la transacción no se completa: conserva el mensaje para revisarlo.
6. Sube el **index.html independiente** de la entrega a la raíz del repositorio, reemplazando el actual. El `index.html` de la carpeta del código es modular; para subir solo un archivo, utiliza el de la entrega o `dist/index.html` generado por el script.
7. Descarga **Que-Pinta-APK-de-prueba** de la ejecución verde, extrae `app-debug.apk` e instálala. La versión nativa será **3.0.0**. Abre la app, inicia sesión y completa la declaración de edad.

El código nuevo no está subido automáticamente a GitHub y el SQL no está aplicado todavía al servidor. Antes de activar el SQL se puede explorar, pero el registro y la participación de la versión 3 esperan a la activación. Una vez activado, las cuentas anteriores deben completar su fecha en v3 para participar. No se borran sus planes.

El código fuente de la APK se toma del ZIP, no del HTML publicado en Pages: hay que actualizar ambos para que web y APK coincidan.

Si Android informa que la firma de esta APK no coincide con la instalada, se debe a que los compiladores de prueba pueden generar claves distintas. Las cuentas y los planes están en Supabase; desinstalar borra la sesión y los guardados locales del teléfono. Para mantener actualizaciones firmadas a largo plazo será necesaria una clave de lanzamiento estable. Esta entrega usa firma de prueba y no es una publicación en Google Play.

## Comprobación después de instalar

- Declarar una fecha adulta en una cuenta anterior y crear un encuentro con pin. Abrir el mismo encuentro desde la web y comprobar ciudad, hora y marcador.
- Crear un encuentro en otro país con su zona horaria y moneda; buscarlo cambiando la ubicación.
- Entrar con una segunda cuenta adulta, unirse y comprobar el chat y las plazas.
- Guardar enlaces sociales con la casilla apagada y comprobar con otra cuenta que no se muestran; encenderla y comprobarlos otra vez.
- Rechazar una fecha menor de 18 en el registro. No utilizar identidades reales de menores para pruebas.
- Probar el mapa manualmente y el botón de ubicación tanto con permiso concedido como rechazado.
- Comprobar que la hora y la barra de navegación del teléfono no cubren controles.

## Ejecutar y preparar desde un ordenador

Requiere Node 22+, JDK 21 y Android SDK 35 para la APK.

```sh
node scripts/checks.cjs
node scripts/flow-checks.cjs
node scripts/standalone.mjs
npm --prefix mobile install
node scripts/prepare-android.mjs
cd mobile
npx cap add android
npx cap sync android
cd android
bash gradlew assembleDebug --no-daemon
```

El hook `capacitor:sync:after` instala los recursos nativos, los permisos y la versión. Los módulos de Supabase y Leaflet se copian dentro de la APK. La web independiente usa sus versiones fijas desde CDN. Internet sigue siendo necesario para cuentas, planes, chat, búsquedas y mapas.

Las dependencias directas están fijadas. La resolución local quedó bloqueada por la red del entorno, por lo que no se inventó un `package-lock.json`. GitHub generará uno y lo entregará como segundo artefacto; consérvalo en `mobile/package-lock.json` del proyecto para las siguientes compilaciones.

## Datos y permisos

El instalador amplía `pinta_plans` con país, ciudad, zona horaria, coordenadas, costo y moneda, y amplía los perfiles con enlaces sociales. Retira únicamente un CHECK de los cuatro barrios iniciales si existe exactamente esa lista en una restricción de la columna de barrio. Añade una validación de longitud sin invalidar datos históricos. Conserva las demás políticas, índices y datos del prototipo.

`qp_age_declarations` mantiene una sola declaración por cuenta. El cliente solo puede insertar la suya y leer su identificador, nunca las fechas desde la API ni modificar declaraciones existentes. La fecha de alta también queda en los metadatos privados de Auth, que no se copian al perfil público. El trigger de registro usa el rol interno `supabase_auth_admin`, funciones invoker y privilegios explícitos. Las reglas de participación consultan la declaración guardada; no usan metadatos editables del JWT para autorizar.

Las políticas nuevas de edad son restrictivas y se combinan con las reglas existentes de dueño y participante. El archivo debe ejecutarse con la cuenta administrativa del proyecto mediante su SQL Editor. Las pruebas de CI reproducen la estructura esperada del prototipo; no sustituyen la validación contra cualquier personalización adicional de la base real.

## Proveedores del mapa

Se utiliza Leaflet 1.9.4, mapas de OpenStreetMap y búsqueda Photon. La búsqueda se realiza al pulsar Buscar, con resultados en caché de sesión y control de solicitudes, sin consultas por cada tecla. No se descargan áreas para uso sin conexión ni se precargan mapas de planes fuera de pantalla.

El servicio público de Photon permite proyectos con un volumen moderado, sin garantía de disponibilidad. OSM también es un servicio de capacidad limitada. Antes de crecer a gran escala conviene contratar un proveedor o alojar el servicio. Los endpoints se pueden cambiar en la fila `maps` de `qp_app_config` (solo administración puede escribir). Un proveedor sustituto debe tener una API compatible con Photon para la búsqueda y mosaicos XYZ para el mapa.

Referencias de implementación: [Leaflet](https://leafletjs.com/reference.html), [uso de mosaicos OSM](https://operations.osmfoundation.org/policies/tiles/), [Photon y su servicio público](https://github.com/komoot/photon#demo-server), [datos de usuarios de Supabase](https://supabase.com/docs/guides/auth/managing-user-data), [RLS](https://supabase.com/docs/guides/database/postgres/row-level-security), [configuración de Capacitor 7](https://capacitorjs.com/docs/v7/config) y [hooks de compilación](https://capacitorjs.com/docs/cli/hooks).

## Verificación de esta entrega

Pasaron 18 comprobaciones de lógica/estructura, 5 flujos con DOM y API simulados y la preparación nativa sobre una plantilla aislada, incluida la repetición de la sincronización. Se comprobó la estructura HTML y los recursos del icono.

No se ejecutaron aquí las pruebas PostgreSQL, la compilación Android ni pruebas con un navegador real: el entorno no tiene esos ejecutores y su red bloquea la instalación de dependencias y el acceso al servidor. El flujo de GitHub incluye las pruebas de base de datos y la compilación. Las pruebas con el dispositivo y la base de datos reales siguen siendo necesarias después de activar la actualización.

No incluye verificación documental, autenticación con Meta, notificaciones push, reputación, invitaciones privadas, moderación ni publicación en tiendas.
