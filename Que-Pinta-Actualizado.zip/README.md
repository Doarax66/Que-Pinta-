# Que Pinta · actualización 2

Una actualización de la web original para descubrir y organizar planes en Montevideo. Conserva el proyecto Supabase, su clave pública, la URL de GitHub Pages y las tablas `pinta_plans` / `pinta_participants` del archivo recibido.

## Para actualizar la web desde el celular

La descarga separada llamada `index.html` reúne el diseño, las imágenes y el código de esta versión en un archivo. Reemplazá el `index.html` de tu repositorio con ese archivo. No pegues un archivo ZIP dentro del repositorio como sustituto del código.

Enlace para subirlo: https://github.com/Doarax66/Que-Pinta-/upload/main

Confirmá el cambio con **Commit changes**. Después de que GitHub Pages termine de publicar, abrí https://doarax66.github.io/Que-Pinta-/ y recargá. En caso de ver el diseño anterior, probá una pestaña nueva.

El ZIP completo contiene el código modular para continuar desarrollando. Si usás esta versión modular, subí juntos `index.html`, `styles.css`, `core.js`, `app.js` y la carpeta `assets`.

## Qué cambia

- Identidad en violeta y naranja, navegación lateral en PC e inferior en móvil.
- Portadas ilustrativas de actividades, tarjetas con participantes reales y cupos.
- Buscador que encuentra texto en título, descripción, barrio y lugar; ignora tildes.
- Filtros por actividad, barrio, hoy, mañana, fin de semana y lugares disponibles.
- Guardados en el dispositivo, disponibles sin registrarse.
- Detalle del plan, confirmación para salir, enlaces compartibles y control de cupos.
- Perfil editable: nombre, descripción, intereses y foto a través de un enlace HTTPS.
- Estados de carga, error y lista vacía; ideas para organizar un plan sin inventar eventos ni participantes.
- Se mantienen registro, confirmación por correo, inicio y cierre de sesión, recuperación de contraseña, creación y cancelación de planes.

## Activación de las funciones nuevas de comunidad

El ZIP original no incluía el esquema de las tablas, perfiles públicos ni chats. No se modificó tu base de datos desde esta sesión.

El archivo `supabase/ACTIVAR-FUNCIONES.sql` agrega tres tablas: `qp_profiles`, `qp_messages` y `qp_plan_details`. Hay que ejecutarlo en el SQL Editor del mismo proyecto Supabase. Este instalador no agrega tablas de planes nuevas ni reemplaza las existentes. Si detecta que las tablas originales no tienen RLS, se detiene para que se revisen sus permisos.

Una vez aplicado, recargá la web e iniciá sesión. Después:

- **Chat de grupo:** solo para el organizador y los participantes. La base de datos comprueba el acceso tanto al leer como al escribir. Los mensajes se actualizan cada 6,5 segundos mientras el chat está abierto; se muestran los últimos 100.
- **Perfil público:** cada persona publica nombre, foto, descripción e intereses al guardar su perfil. El correo no se copia a la tabla pública. Los nombres históricos de los planes conservan el nombre usado al inscribirse.
- **Costo y filtro Gratis:** los planes nuevos permiten indicar costo estimado en pesos uruguayos. Los planes anteriores, sin costo conocido, no se clasifican como gratuitos.

Sin ejecutar el instalador, el rediseño y las funciones existentes siguen usando las tablas originales; el perfil se guarda en la cuenta, el chat informa que falta habilitarlo, y el campo de costo y el filtro Gratis no aparecen.

No se incluyen todavía verificación con documento, expulsiones por votación, puntos de fama, invitaciones, notificaciones push ni publicación en tiendas.

## Preparación de APK de prueba

**Este paquete no contiene una APK compilada.** El entorno de trabajo tenía Node, pero no JDK de compilación, Android SDK ni Gradle. La descarga de dependencias de Capacitor fue bloqueada por la red (HTTP 403). No se ejecutó el flujo de GitHub ni se probó en un teléfono.

Se incluye `.github/workflows/android.yml`, que se inicia manualmente en GitHub Actions; no publica la web ni la app automáticamente. Para usarlo hay que subir el proyecto completo con la carpeta `.github`, `mobile` y `scripts`, además de los archivos de la web.

1. Abrí la pestaña **Actions** del repositorio.
2. Elegí **Crear APK de prueba** y ejecutá **Run workflow**.
3. Si termina correctamente, descargá el archivo **Que-Pinta-APK-de-prueba** en **Artifacts**. Dentro estará `app-debug.apk`.
4. Guardá también el artefacto `Que-Pinta-package-lock`; incorporá ese archivo a `mobile/package-lock.json` para reutilizar las versiones resueltas en compilaciones futuras.

El flujo usa Node 22, Java 21, Android SDK 35 y Capacitor 7.6.8, con el complemento App 7.0.0. Todas las dependencias directas se fijan por versión. El archivo de bloqueo no pudo generarse aquí porque el registro npm está bloqueado. La primera ejecución lo resolverá y las siguientes usarán `npm ci` si se guarda en el repositorio.

Para compilar desde una PC con las herramientas de Android instaladas:

```sh
npm --prefix mobile install
node scripts/prepare-android.mjs
cd mobile
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

En Windows, usar `gradlew.bat assembleDebug` en el último paso. `npx cap add android` solo se ejecuta la primera vez. Conservá el directorio `mobile/android` si empezás a personalizar iconos o ajustes nativos.

La APK de prueba utiliza firma de desarrollo e iconos nativos iniciales de Capacitor. El icono definitivo, la firma de distribución y las pruebas en dispositivos quedan para una compilación verificada. Los enlaces de confirmación y recuperación de cuenta siguen abriendo la web existente; al confirmar el correo podés iniciar sesión en la app. No hay enlaces profundos Android configurados. La conexión a usuarios y planes requiere internet; las bibliotecas y portadas se empaquetan con la app.

## Comprobaciones realizadas

- Sintaxis JavaScript de la app, las reglas y los scripts de preparación.
- 12 comprobaciones locales de cupos, organizador/participante, búsqueda con tildes, fechas y límites de día de Montevideo, fin de semana, escape de HTML, enlaces HTTPS de fotos, paginación sin duplicados, controles presentes y archivos referenciados.
- Generación del HTML independiente y comprobación de su código integrado.

No se probaron cuentas reales ni se publicaron o borraron planes de producción. La conexión a Supabase desde este entorno no pudo completarse y el instalador SQL no se ejecutó. Las políticas nuevas deben comprobarse con un organizador, un participante, otra cuenta ajena al grupo y un visitante antes de habilitar los chats para una comunidad real. No se realizó una sesión de pruebas en navegador o teléfono.

## Desarrollo

No se necesitan dependencias npm para la versión web; solo un servidor HTTP estático y conexión a Supabase. Por ejemplo:

```sh
python3 -m http.server 8080
node scripts/checks.cjs
node scripts/standalone.mjs
```

`standalone.mjs` produce `dist/index.html` a partir de los archivos fuente, con imágenes y estilos integrados. Los guardados son preferencias locales de cada navegador; no se sincronizan entre dispositivos. La clave incluida es la clave pública del proyecto original; los permisos de escritura deben estar respaldados por RLS, nunca por la clave del cliente.

## Fuentes técnicas

- Supabase, datos de perfil: https://supabase.com/docs/reference/javascript/auth-updateuser
- Supabase, permisos y RLS: https://supabase.com/docs/guides/database/postgres/row-level-security
- Capacitor 7, requisitos: https://capacitorjs.com/docs/v7/updating/7-0
- Capacitor Android: https://capacitorjs.com/docs/v7/android
- Capacitor 7.6.8: https://github.com/ionic-team/capacitor/releases/tag/7.6.8

Las tres portadas de actividades se generaron para esta actualización. Son imágenes ilustrativas; no documentan los encuentros publicados.
