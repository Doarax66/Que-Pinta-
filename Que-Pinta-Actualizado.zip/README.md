# Que Pinta 4

Lee [README-V4.md](README-V4.md) para los cambios, validación y límites de esta versión.

Para instalar desde el teléfono, consulta [LEEME-PRIMERO.txt](LEEME-PRIMERO.txt).
