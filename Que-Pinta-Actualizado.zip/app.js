'use strict';
// Existing project connection; only the public (browser-safe) key is used.
const PROJECT_URL = 'https://duieibwtyxrqfzlhqbap.supabase.co';
const PUBLIC_KEY = 'sb_publishable_CPK0XrZ2o4ivRb1VpTh3hw_ADYw26EH';
const SITE_URL = 'https://doarax66.github.io/Que-Pinta-/';
const FIELDS = 'id,owner_id,owner_name,title,category,neighborhood,meeting_point,starts_at,capacity,description,pinta_participants(user_id,display_name,seat)';
const V3_FIELDS = ',qp_country_code,qp_city,qp_timezone,qp_latitude,qp_longitude,qp_cost,qp_currency';
const C = window.PintaCore;
const $ = id => document.getElementById(id);
const esc = C.escapeHTML;
const categories = {Todos:{label:'Todos los planes',emoji:'✳',icon:'compass'},Deporte:{label:'Deportes',emoji:'⚽',icon:'sport'},Comida:{label:'Comer algo',emoji:'☕',icon:'coffee'},Juegos:{label:'Juegos',emoji:'🎮',icon:'game'},Paseos:{label:'Al aire libre',emoji:'🌿',icon:'compass'}};
const paths = {
  coffee:'<path d="M4 8h12v7a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5V8Zm12 1h2a3 3 0 1 1 0 6h-2M3 22h15M8 2v3m5-3v3"/>',
  sport:'<circle cx="12" cy="12" r="9"/><path d="m12 8 4 3-2 5h-4l-2-5 4-3Zm0 0V3m4 8 5-2m-7 7 3 4m-7-4-3 4m1-9L3 9"/>',
  compass:'<circle cx="12" cy="12" r="9"/><path d="m16 8-2.5 5.5L8 16l2.5-5.5L16 8Z"/>',
  calendar:'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v4m10-4v4M3 11h18m-13 4h2m4 0h2"/>',
  bookmark:'<path d="M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16l-6-4-6 4Z"/>',
  chat:'<path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5 9.6 9.6 0 0 1-4-.9L3 21l1.9-5.5a9.6 9.6 0 0 1-.9-4A8.5 8.5 0 0 1 12.5 3h.5a8.5 8.5 0 0 1 8 8v.5Z"/><path d="M8 10h8m-8 4h5"/>',
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  pin:'<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
  search:'<circle cx="10.5" cy="10.5" r="7"/><path d="m16 16 5 5"/>',
  close:'<path d="m6 6 12 12M6 18 18 6"/>',
  arrow:'<path d="M4 12h16m-6-6 6 6-6 6"/>',
  arrowUp:'<path d="M6 18 18 6M7 6h11v11"/>',
  refresh:'<path d="M20 7v5h-5M4 17v-5h5M6 6a8 8 0 0 1 13 3M5 15a8 8 0 0 0 13 3"/>',
  users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2m20 0v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/><circle cx="9" cy="7" r="4"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  share:'<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 10.5 6.8-4m-6.8 7 6.8 4"/>',
  send:'<path d="m22 2-7 20-4-9-9-4 20-7ZM22 2 11 13"/>',
  check:'<path d="m5 12 4 4L19 6"/>',
  game:'<path d="M7 7h10a4 4 0 0 1 3.8 3l1.1 6.3a3 3 0 0 1-5 2.7L14 16h-4l-2.9 3a3 3 0 0 1-5-2.7L3.2 10A4 4 0 0 1 7 7Z"/><path d="M7 10v5m-2.5-2.5h5M15 11h.01M18 14h.01"/>',
  wallet:'<path d="M20 7H5a2 2 0 0 1 0-4h13v4m2 0v14H5a3 3 0 0 1-3-3V5m18 7h-5v5h5"/>'
};
const icon = name => `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${paths[name] || paths.compass}</svg>`;
function paintIcons(root=document) { root.querySelectorAll('[data-icon]').forEach(el => { el.innerHTML=icon(el.dataset.icon); }); }
let db, user=null, ready=false, initializing=false, view='explore', activity='Todos', dateFilter='all', onlyFree=false, onlySeats=false;
let plans=[], hasMore=false, offset=0, selectedId=null, selectedPlan=null, requestNumber=0, detailTicket=0, actionBusy=false, toastTimer;
let authMode='login', afterAuth=null, pendingIdea=null, openedShared=false, searchTimer, chatId=null, chatTimer, chatTicket=0, chatReadBusy=false, chatListTicket=0, pendingMessage=null;
let capabilities={profiles:false,messages:false,details:false,v3:false,age:false};
let cardObserver=null,adultUserId=null,afterAge=null,createMap=null,detailMap=null,meetingPin=null,mapSearchTicket=0;
let countryFilter='UY',cityFilter='Montevideo';
try{const v=JSON.parse(localStorage.getItem('qp.location.v3'));if(v&&(!v.country||PintaGeo[v.country])){countryFilter=v.country||'';cityFilter=String(v.city||'').slice(0,80);}}catch{}
const regionNames=new Intl.DisplayNames(['es'],{type:'region'});
const countryName=code=>code?regionNames.of(code):'Todos los países';
const fields=()=>FIELDS+(capabilities.v3?V3_FIELDS:'');
const publicProfiles=new Map();
let saved=new Set();
try { const value=JSON.parse(localStorage.getItem('qp.saved.v2')||'[]'); if(Array.isArray(value))saved=new Set(value.filter(id=>typeof id==='string'&&/^[a-zA-Z0-9_-]{1,80}$/.test(id))); } catch {}
const participants = C.participants, owns = p=>C.owns(p,user), attends = p=>C.attends(p,user);
const nameOfUser = ()=>String(user?.user_metadata?.display_name||'Participante').trim().slice(0,40)||'Participante';
function notice(text) { $('toast').textContent=text; clearTimeout(toastTimer); toastTimer=setTimeout(()=>$('toast').textContent='',4800); }
function openDialog(id) { if(!$(id).open)$(id).showModal(); }
function requireConnection() { if(ready&&db)return true; notice('La conexión todavía no está lista. Toca Actualizar para volver a intentar.');return false; }
async function boundedRead(request,ms=15000) { let timer;try{return await Promise.race([request,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('La conexión está tardando. Toca Actualizar para volver a intentar.')),ms);})]);}finally{clearTimeout(timer);} }
function explain(error) {
  const code=error?.code||'',message=String(error?.message||error||'');
  if(code==='invalid_credentials')return 'El correo o la contraseña no coinciden.';
  if(code==='email_not_confirmed')return 'Confirma tu correo con el enlace que recibiste antes de entrar.';
  if(/over_.*rate_limit/.test(code)||/rate limit/i.test(message))return 'Espera unos minutos antes de volver a intentarlo.';
  if(code==='weak_password')return 'Usa una contraseña más segura, de al menos 10 caracteres.';
  if(code==='signup_disabled')return 'El registro todavía no está habilitado.';
  if(code==='user_already_exists')return 'Ya existe una cuenta. Prueba entrar o recuperar tu contraseña.';
  if(code==='email_address_not_authorized')return 'El envío de correos todavía necesita configuración.';
  if(['42P01','42703','PGRST200','PGRST204','PGRST205'].includes(code))return 'Esta función todavía necesita activarse. Los planes existentes siguen disponibles.';
  if(/18 años|nacimiento/.test(message))return 'Debes declarar una fecha de nacimiento válida y tener al menos 18 años.';
  if(code==='42501')return 'No tienes acceso a esta acción. Revisa tu sesión y que sigas dentro del plan.';
  if(['23503','PGRST116'].includes(code))return 'Este plan ya no está disponible. Actualiza la lista.';
  if(code==='23505')return 'Ese lugar acaba de ocuparse o ya estás en el plan. Actualiza e intenta de nuevo.';
  if(/fetch|network|offline/i.test(message))return 'No pudimos conectarnos. Revisa internet y vuelve a intentar.';
  if(!code&&message)return message;
  return 'No pudimos completar la acción. Vuelve a intentar.';
}
function setLoadError(message) { $('load-error').textContent=message;$('load-error').hidden=!message; }
function avatar(name,id,cls='avatar') {
  const profile=publicProfiles.get(id), photo=C.safePhoto(profile?.avatar_url||'');
  return `<span class="${cls}" aria-hidden="true">${photo?`<img src="${esc(photo)}" alt="" referrerpolicy="no-referrer" loading="lazy">`:esc(C.initials(name))}</span>`;
}
function profilePhoto(value) { const p=C.safePhoto(value);return p?`<img src="${esc(p)}" alt="" referrerpolicy="no-referrer">`:esc(C.initials(nameOfUser())); }
function categoryOf(p) { return categories[p.category]||categories.Paseos; }
function cover(p) { const c=categoryOf(p);return `<div class="symbol-cover cover-${esc(p.category)}"><span class="cover-orbit"></span><span class="cover-symbol">${icon(c.icon)}</span><span class="cover-caption">UN PLAN. NUEVAS HISTORIAS.</span></div>`; }
function costText(p) { const cost=p.qp_cost??p.details?.cost_uyu,currency=p.qp_currency||'UYU';return cost===0?'Gratis':cost!=null?new Intl.NumberFormat('es',{style:'currency',currency,currencyDisplay:'code',maximumFractionDigits:2}).format(cost):''; }
function localDate(p){return C.dateLabel(p.starts_at,new Date(),p.qp_timezone||C.ZONE);}
function placeLabel(p){return [p.neighborhood,p.qp_city||'Montevideo'].filter(Boolean).filter((x,i,a)=>a.indexOf(x)===i).join(' · ');}

function card(p) {
  const c=categoryOf(p),free=C.freeSeats(p),members=[{user_id:p.owner_id,display_name:p.owner_name},...participants(p)];
  const spot=owns(p)?'Lo organizas tú':attends(p)?'Ya estás en el plan':!free?'Plan completo':free===1?'¡Última plaza!':`${free} plazas libres`;
  return `<article class="plan-card"><div class="card-cover">${cover(p)}<button class="cover-open" data-plan="${esc(p.id)}" aria-label="Ver ${esc(p.title)}"></button><span class="category-badge">${c.emoji} ${esc(c.label)}</span><button class="icon-button save-button" data-save="${esc(p.id)}" aria-label="${saved.has(p.id)?'Quitar de guardados':'Guardar'}: ${esc(p.title)}" aria-pressed="${saved.has(p.id)}">${icon('bookmark')}</button></div><div class="card-content"><p class="card-date">${esc(localDate(p))}</p><h3 class="card-title"><button data-plan="${esc(p.id)}">${esc(p.title)}</button></h3><p class="card-meta">${icon('pin')}${esc(placeLabel(p))}${costText(p)?`<span class="cost-label">${esc(costText(p))}</span>`:''}</p><p class="card-description">${esc(p.description)}</p><div class="card-social"><div class="avatar-stack">${members.slice(0,3).map(m=>avatar(m.display_name,m.user_id)).join('')}${members.length>3?`<span class="avatar">+${members.length-3}</span>`:''}</div><span class="people-count">${members.length===1?'Lo organiza '+esc(p.owner_name):`${members.length} personas se suman`}</span></div><div class="card-footer"><span class="spots ${attends(p)?'joined':free===1?'urgent':''}">${spot}</span><button class="card-link" data-plan="${esc(p.id)}" aria-label="Ver plan: ${esc(p.title)}">Ver plan ${icon('arrowUp')}</button></div></div></article>`;
}
function emptyHTML(title,text,action='create') {return `<div class="empty-state"><div class="empty-icon">${icon(view==='saved'?'bookmark':view==='chats'?'chat':'compass')}</div><h2>${esc(title)}</h2><p>${esc(text)}</p><button class="primary" ${action==='create'?'data-create':'data-reset'}>${action==='create'?icon('plus')+'Crear un plan':'Ver todos los planes'}</button></div>`;}
function updateViewUI() {
  document.querySelectorAll('[data-view]').forEach(b=>{if(b.dataset.view===view)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
  document.querySelectorAll('[data-category]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.category===activity));
  document.querySelectorAll('[data-date]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.date===dateFilter));
  $('seats-filter').setAttribute('aria-pressed',onlySeats);$('free-filter').setAttribute('aria-pressed',onlyFree);
  $('discover-view').hidden=view==='chats';$('chats-view').hidden=view!=='chats';
  $('page-title').innerHTML=view==='mine'?'Tus próximos <span>planes.</span>':view==='saved'?'Para <span>después.</span>':'¿Qué pinta <span>hoy?</span>';
  $('eyebrow').textContent=view==='mine'?'YA TIENES CON QUIÉN':view==='saved'?'QUE NO SE TE ESCAPE':'✳ SAL DE LA RUTINA';
  $('page-intro').textContent=view==='mine'?'Los que organizas y los que ya te esperan.':view==='saved'?'Esos planes que te dieron ganas.':'Haz espacio para algo nuevo. Encuentra tu próximo plan.';
  $('list-title').textContent=view==='mine'?'Nos vemos ahí':view==='saved'?'Tus planes guardados':'Tu próximo buen plan';
  $('save-hint').hidden=view!=='saved';$('inspiration').hidden=view!=='explore';
  $('reset-filters').hidden=activity==='Todos'&&dateFilter==='all'&&!onlyFree&&!onlySeats&&!$('zone').value&&!$('search').value;
  $('clear-search').hidden=!$('search').value;
}
function render() {
  updateLocationLabels();
  updateViewUI();$('count').textContent=`${plans.length}${hasMore?'+':''} ${plans.length===1?'plan':'planes'}`;$('more').hidden=!hasMore;
  if(plans.length){$('plans').innerHTML=plans.map(card).join('');animateCards();return;}
  const filtered=activity!=='Todos'||dateFilter!=='all'||onlyFree||onlySeats||$('zone').value||$('search').value;
  $('plans').innerHTML=filtered?emptyHTML('Por aquí todavía no hay planes.','Prueba con otra fecha, actividad o barrio.','reset'):view==='mine'?emptyHTML('Tu agenda está por despegar.','Únete a un plan o propón el tuyo.'):view==='saved'?emptyHTML('Guarda lo que te dé ganas.','Toca el marcador en un plan para encontrarlo aquí después.','reset'):emptyHTML('El primer plan puede ser tuyo.','Una vuelta, un café o un partido. Propón algo y deja que se sumen.');
}
function skeletons(){return Array.from({length:2},()=>'<div class="loading-card"><div class="skeleton-cover"></div><div class="skeleton-line"></div><div class="skeleton-line short"></div></div>').join('');}
async function myPlanIds(userId) {
  const ids=[];
  for(let start=0;;start+=500){const {data,error}=await boundedRead(db.from('pinta_participants').select('plan_id').eq('user_id',userId).order('plan_id').range(start,start+499));if(error)throw error;ids.push(...data.map(r=>r.plan_id));if(data.length<500)return ids;}
}
async function enrich(rows) {
  if(!rows.length)return rows;
  const jobs=[];const details=new Map();
  if(capabilities.details)jobs.push(boundedRead(db.from('qp_plan_details').select('plan_id,cost_uyu').in('plan_id',rows.map(r=>r.id))).then(({data,error})=>{if(error)throw error;data.forEach(d=>details.set(d.plan_id,d));}));
  if(capabilities.profiles){const ids=[...new Set(rows.flatMap(p=>[p.owner_id,...participants(p).map(m=>m.user_id)]))];jobs.push(boundedRead(db.from('qp_profiles').select('id,display_name,avatar_url').in('id',ids)).then(({data,error})=>{if(!error)data.forEach(p=>publicProfiles.set(p.id,p));}));}
  await Promise.all(jobs);return rows.map(p=>({...p,id:String(p.id),details:details.get(p.id)||null}));
}
async function loadPlans(append=false) {
  if(view==='chats')return loadChatList();
  if(!ready||!db)return;
  const ticket=++requestNumber,currentUser=user?.id,queryText=$('search').value.trim(),filters={activity,date:dateFilter,zone:$('zone').value,country:countryFilter,city:cityFilter,free:onlyFree,seats:onlySeats,view};
  clearTimeout(searchTimer);updateViewUI();setLoadError('');$('reload').disabled=true;$('more').disabled=true;$('plans').setAttribute('aria-busy','true');
  if(!append){cardObserver?.disconnect();plans=[];offset=0;hasMore=false;$('plans').innerHTML=skeletons();$('count').textContent='Buscando…';$('more').hidden=true;}
  try{
    if(filters.view==='mine'&&!currentUser){render();return;}
    const ids=filters.view==='mine'?await myPlanIds(currentUser):[];
    if(ticket!==requestNumber)return;
    if(filters.view==='saved'&&!saved.size){render();return;}
    const initialCount=plans.length;
    do {
      let q=db.from('pinta_plans').select(fields()).order('starts_at').order('id');
      q=q.gte('starts_at',new Date().toISOString());
      if(capabilities.v3&&filters.country)q=q.eq('qp_country_code',filters.country);
      if(filters.activity!=='Todos')q=q.eq('category',filters.activity);
      // City, neighborhood and calendar filters run after the country query, ignoring accents.
      if(filters.view==='mine')q=ids.length?q.or(`owner_id.eq.${currentUser},id.in.(${ids.join(',')})`):q.eq('owner_id',currentUser);
      if(filters.view==='saved')q=q.in('id',[...saved]);
      const {data,error}=await boundedRead(q.range(offset,offset+79));if(error)throw error;
      if(ticket!==requestNumber)return;
      const rows=await enrich(data);if(ticket!==requestNumber)return;
      offset+=data.length;hasMore=data.length===80;
      plans=C.mergeUnique(plans,rows.filter(p=>C.matchesSearch(p,queryText)&&C.matchesDate(p,filters.date)&&(!filters.country||(p.qp_country_code||'UY')===filters.country)&&(!filters.city||C.normalize(p.qp_city||'Montevideo').includes(C.normalize(filters.city)))&&(!filters.zone||C.normalize(p.neighborhood).includes(C.normalize(filters.zone)))&&(!filters.seats||C.freeSeats(p)>0)&&(!filters.free||(p.qp_cost??p.details?.cost_uyu)===0)));
    }while(hasMore&&plans.length-initialCount<12);
    render();
  }catch(error){if(ticket!==requestNumber)return;setLoadError(explain(error));if(!append){$('plans').innerHTML='';$('count').textContent='Sin conexión';}}
  finally{if(ticket===requestNumber){$('reload').disabled=false;$('more').disabled=false;$('plans').setAttribute('aria-busy','false');}}
}
function resetFilters(){activity='Todos';dateFilter='all';onlyFree=false;onlySeats=false;$('zone').value='';$('search').value='';updateViewUI();}
async function goView(next) {
  if((next==='mine'||next==='chats')&&!user){if(requireConnection())openAuth('login',{view:next});return;}
  ++requestNumber;++chatListTicket;view=next;resetFilters();updateViewUI();
  if(next==='chats')await loadChatList();else await loadPlans();
}
function toggleSave(id) {
  const next=new Set(saved);if(next.has(id))next.delete(id);else next.add(id);
  try{localStorage.setItem('qp.saved.v2',JSON.stringify([...next]));}catch{notice('El navegador no permite guardar en este dispositivo.');return;}
  saved=next;
  document.querySelectorAll('[data-save]').forEach(b=>{if(b.dataset.save===id){b.setAttribute('aria-pressed',saved.has(id));b.setAttribute('aria-label',saved.has(id)?'Quitar de guardados':'Guardar plan');}});
  if(selectedId===id){$('save-detail').setAttribute('aria-pressed',saved.has(id));$('save-detail').setAttribute('aria-label',saved.has(id)?'Quitar de guardados':'Guardar plan');}
  if(view==='saved')loadPlans();
  notice(saved.has(id)?'Plan guardado en este dispositivo.':'Plan quitado de guardados.');
}
function planLink(id) {const u=new URL(SITE_URL);u.searchParams.set('plan',id);return u.href;}
async function readPlan(id){const {data,error}=await boundedRead(db.from('pinta_plans').select(fields()).eq('id',id).single());if(error)throw error;return (await enrich([data]))[0];}
function detailHTML(p){
  selectedPlan=p;const c=categoryOf(p),members=[{user_id:p.owner_id,display_name:p.owner_name,host:true},...participants(p)],past=new Date(p.starts_at)<=new Date();
  $('detail-cover').innerHTML=cover(p);$('detail-title').textContent=p.title;$('detail-category').innerHTML=`<span class="category-badge">${c.emoji} ${esc(c.label)}</span>`;
  $('detail-body').innerHTML=`<div class="detail-facts"><div class="detail-fact"><span class="fact-icon">${icon('calendar')}</span><div><strong>${esc(localDate(p))}</strong><small>Hora de ${esc(p.qp_city||'Montevideo')} · ${esc((p.qp_timezone||C.ZONE).split('/').pop().replaceAll('_',' '))}</small></div></div><div class="detail-fact"><span class="fact-icon">${icon('pin')}</span><div><strong>${esc(placeLabel(p))}</strong><small>${esc(p.meeting_point)}</small></div></div>${costText(p)?`<div class="detail-fact"><span class="fact-icon">${icon('wallet')}</span><div><strong>${esc(costText(p))}</strong><small>${(p.qp_cost??p.details?.cost_uyu)===0?'Sin costo de participación':'Costo estimado por persona'}</small></div></div>`:''}</div><h3>¿De qué va el plan?</h3><p class="detail-description">${esc(p.description)}</p>${attends(p)?`<div class="detail-status">${icon('check')} ${owns(p)?'Este plan lo organizas tú.':'¡Tienes tu plaza en este plan!'}</div>`:''}<div class="people-heading"><h3>Quiénes se suman</h3><span class="capacity-pill">${members.length} / ${p.capacity}</span></div><div class="people-list">${members.map(m=>`<${capabilities.profiles?'button':'div'} class="person-row" ${capabilities.profiles?`data-person="${esc(m.user_id)}" data-name="${esc(m.display_name)}"`:''}>${avatar(m.display_name,m.user_id)}<span><strong>${esc(m.display_name)}${m.user_id===user?.id?' (tú)':''}</strong><small>${m.host?'Organiza el plan':'Se suma al plan'}</small></span>${capabilities.profiles?`<span>${icon('arrowUp')}</span>`:''}</${capabilities.profiles?'button':'div'}>`).join('')}</div>`;
  showMeetingMap(p);
  $('join').textContent=owns(p)?'Tú organizas este plan':attends(p)?'Salir del plan':past?'El plan ya comenzó':C.nextSeat(p)===null?'Plan completo':user?'¡Me uno!':'Entrar para unirme';
  $('join').disabled=actionBusy||owns(p)||(!attends(p)&&(past||C.nextSeat(p)===null));
  $('save-detail').setAttribute('aria-pressed',saved.has(p.id));$('save-detail').disabled=false;$('save-detail').setAttribute('aria-label',saved.has(p.id)?'Quitar de guardados':'Guardar plan');
  $('cancel-plan').hidden=!owns(p);$('share-plan').hidden=false;$('share-link').value=planLink(p.id);$('open-plan-chat').hidden=!attends(p)||!capabilities.messages;
}
async function showPlan(id){
  if(!requireConnection())return;const ticket=++detailTicket;selectedId=id;selectedPlan=null;
  detailMap?.remove();detailMap=null;$('detail-map-section').hidden=true;$('directions').hidden=true;
  $('detail-error').textContent='';$('detail-title').textContent='Cargando plan…';$('detail-category').textContent='';$('detail-body').innerHTML='<p class="muted">Buscando los detalles…</p>';$('detail-cover').innerHTML='';
  $('share-plan').hidden=true;$('share-fallback').hidden=true;$('join').disabled=true;$('save-detail').disabled=true;$('cancel-plan').hidden=true;$('open-plan-chat').hidden=true;openDialog('detail');
  try{const p=await readPlan(id);if(selectedId===id&&ticket===detailTicket)detailHTML(p);}catch(error){if(ticket===detailTicket){$('detail-title').textContent='No se pudo abrir el plan';$('detail-error').textContent=explain(error);}}
}
async function sharePlan(){
  const id=selectedId,url=$('share-link').value,title=$('detail-title').textContent;if(!id||$('share-plan').hidden)return;
  try{if(navigator.share){await navigator.share({title,text:'¿Te unes a este plan en Que Pinta?',url});return;}if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(url);notice('Enlace copiado.');return;}}catch(error){if(error.name==='AbortError')return;}
  if(selectedId===id){$('share-fallback').hidden=false;$('share-link').focus();$('share-link').select();}
}
async function changeMembership(allowLeave=false){
  if(actionBusy||!selectedId)return;
  if(!user){openAuth('login',{plan:selectedId});return;}
  if(!allowLeave&&(!selectedPlan||!attends(selectedPlan))&&!await ensureAdult({plan:selectedId}))return;
  if(selectedPlan&&attends(selectedPlan)&&!owns(selectedPlan)&&!allowLeave){openDialog('confirm-leave');return;}
  const id=selectedId,actor=user.id;actionBusy=true;$('join').disabled=true;$('detail-error').textContent='';
  try{
    let p=await readPlan(id);if(user?.id!==actor)throw Error('Tu sesión cambió. Vuelve a entrar.');if(owns(p))return;
    if(attends(p)){
      if(!allowLeave){openDialog('confirm-leave');return;}
      const {error}=await db.from('pinta_participants').delete().eq('plan_id',id).eq('user_id',actor);if(error)throw error;notice('Saliste del plan. Tu plaza quedó libre.');
    }else{
      if(allowLeave){notice('Ya habías salido del plan.');return;}
      let success=false;
      // Existing unique(plan_id,seat) constraint arbitrates simultaneous joins.
      for(let attempt=0;attempt<30;attempt++){
        if(user?.id!==actor)throw Error('Tu sesión cambió. Vuelve a entrar.');
        if(new Date(p.starts_at)<=new Date())throw Error('Este plan ya comenzó.');
        if(attends(p)){success=true;break;}const seat=C.nextSeat(p);if(seat===null)throw Error('El plan acaba de completarse.');
        const {error}=await db.from('pinta_participants').insert({plan_id:id,user_id:actor,display_name:nameOfUser(),seat});
        if(!error){success=true;break;}if(error.code!=='23505')throw error;p=await readPlan(id);
      }
      if(!success)throw Error('Los plazas cambiaron. Vuelve a intentarlo.');notice('¡Ya tienes tu plaza! Nos vemos en el plan.');
      $('join').classList.add('joined-flash');setTimeout(()=>$('join').classList.remove('joined-flash'),750);
    }
    await loadPlans();
  }catch(error){if(selectedId===id)$('detail-error').textContent=explain(error);}
  finally{actionBusy=false;try{const p=await readPlan(id);if(selectedId===id)detailHTML(p);}catch(error){if(selectedId===id){$('join').disabled=true;$('detail-error').textContent=explain(error);}}}
}
function authUI(){
  $('account-label').textContent=user?'Mi perfil':'Entrar';const holder=$('account').querySelector('[data-icon]');
  holder.innerHTML=user?`<span class="avatar">${esc(C.initials(nameOfUser()))}</span>`:icon('user');
  $('account-name').textContent=user?nameOfUser():'';$('account-email').textContent=user?.email||'';
}
function openAuth(mode='login',next=null){
  if(!requireConnection())return;
  authMode=mode;afterAuth=next;for(const id of ['detail','create','profile','chat'])if($(id).open)$(id).close();
  $('auth-form').reset();$('auth-message').textContent='';
  $('auth-title').textContent={login:'Entra a Que Pinta.',signup:'Tu próximo plan empieza aquí.',reset:'Recupera tu contraseña.',update:'Elige una contraseña nueva.'}[mode];
  $('birthdate-field').hidden=mode!=='signup';$('auth-birthdate').required=mode==='signup';
  $('name-field').hidden=mode!=='signup';$('auth-name').required=mode==='signup';$('email-field').hidden=mode==='update';$('auth-email').required=mode!=='update';$('password-field').hidden=mode==='reset';$('auth-password').required=mode!=='reset';
  $('auth-password').minLength=mode==='login'?1:10;$('auth-password').autocomplete=mode==='login'?'current-password':'new-password';$('auth-tabs').hidden=mode==='update';$('forgot').hidden=mode!=='login';$('privacy-hint').hidden=mode!=='signup';
  $('login-tab').setAttribute('aria-pressed',mode==='login');$('signup-tab').setAttribute('aria-pressed',mode==='signup');
  $('auth-submit').textContent={login:'Entrar',signup:'Crear cuenta',reset:'Enviar enlace',update:'Guardar contraseña'}[mode];openDialog('auth');
}
async function createPlanDialog(idea=null){
  if(idea)pendingIdea=idea;if(!requireConnection())return;if(!user){openAuth('login',{create:true});return;}
  if(!await ensureAdult({create:true}))return;
  $('create-error').textContent='';$('host-name').value=nameOfUser();
  if(!$('plan-country').value){$('plan-country').value=countryFilter||'UY';$('plan-city').value=cityFilter;populateTimezones();}
  $('date').min=C.inputDate(new Date(Date.now()+60000),$('plan-timezone').value);
  if(pendingIdea){const ideas={walk:{title:'Una vuelta para conocer gente',category:'Paseos'},coffee:{title:'Un café y una buena charla',category:'Comida'},football:{title:'¿Jugamos un partido de fútbol?',category:'Deporte'}};const p=ideas[pendingIdea];if(p){$('title').value=p.title;$('category').value=p.category;}pendingIdea=null;}
  $('cost-field').hidden=false;openDialog('create');initCreateMap();
}
function openProfile(){if(!requireConnection())return;if(!user){openAuth('login',{profile:true});return;}const m=user.user_metadata||{};$('profile-name').value=nameOfUser();$('profile-bio').value=String(m.bio||'').slice(0,240);$('profile-photo').value=C.safePhoto(m.avatar_url);$('profile-avatar').innerHTML=profilePhoto(m.avatar_url);$('profile-error').textContent='';document.querySelectorAll('input[name=interest]').forEach(i=>i.checked=Array.isArray(m.interests)&&m.interests.includes(i.value));$('profile-scope').textContent=capabilities.profiles?'Al guardar, tu nombre, foto, descripción e intereses serán públicos. Tu correo queda privado.':'Tu nombre, foto e intereses se guardan en tu cuenta. El perfil público todavía no está habilitado.';$('profile-instagram').value=String(m.instagram_url||'');$('profile-facebook').value=String(m.facebook_url||'');$('show-socials').checked=m.show_socials===true;openDialog('profile');}
async function resumeAfterAuth(next){if(next?.create)await createPlanDialog();else if(next?.profile)openProfile();else if(next?.view)await goView(next.view);else if(next?.plan)await showPlan(next.plan);else if(next?.chat)await openChat(next.chat);}
async function showPerson(id,name){
  $('person-title').textContent=name;$('person-body').innerHTML='<p class="muted">Cargando perfil…</p>';openDialog('person');
  try{const {data,error}=await boundedRead(db.from('qp_profiles').select('id,display_name,bio,avatar_url,interests'+(capabilities.v3?',instagram_url,facebook_url':'')).eq('id',id).maybeSingle());if(error)throw error;
    if(!data){$('person-body').innerHTML='<p class="muted">Esta persona todavía no completó su perfil público.</p>';return;}
    $('person-title').textContent=data.display_name;const photo=C.safePhoto(data.avatar_url);
    $('person-body').innerHTML=`<div class="profile-person-avatar">${photo?`<img src="${esc(photo)}" alt="Foto de perfil" referrerpolicy="no-referrer">`:esc(C.initials(data.display_name))}</div><p class="detail-description">${esc(data.bio||'Sin descripción todavía.')}</p><div>${(data.interests||[]).filter(c=>categories[c]&&c!=='Todos').map(c=>`<span class="profile-interest">${categories[c].emoji} ${esc(categories[c].label)}</span>`).join('')}</div><div class="social-links">${[['Instagram','instagram',data.instagram_url],['Facebook','facebook',data.facebook_url]].map(([label,network,value])=>{const url=C.socialURL(value,network);return url?`<a class="secondary" href="${esc(url)}" target="_blank" rel="noopener noreferrer">${label} ${icon('arrowUp')}</a>`:'';}).join('')}</div>`;
  }catch(error){$('person-body').textContent=explain(error);}
}
async function detectCapabilities(){
  const keys=[['profiles','qp_profiles','id'],['messages','qp_messages','id'],['details','qp_plan_details','plan_id'],['v3','pinta_plans','qp_country_code,qp_city,qp_timezone,qp_latitude,qp_longitude,qp_cost,qp_currency']];
  await Promise.all(keys.map(async([key,table,field])=>{try{const {error}=await boundedRead(db.from(table).select(field).limit(0),6000);capabilities[key]=!error;}catch{capabilities[key]=false;}}));
  $('free-filter').hidden=!capabilities.v3&&!capabilities.details;$('cost-field').hidden=!capabilities.v3;
  capabilities.age=false;
  if(capabilities.v3){try{const {data,error}=await boundedRead(db.from('qp_app_config').select('key,value').in('key',['maps','release']),4000);if(error)throw error;for(const row of data||[]){if(row.key==='maps')PintaMaps.configure(row.value);if(row.key==='release')capabilities.age=row.value?.version===3&&row.value?.adultDeclaration===true;}}catch{}}
}
async function loadChatList(){
  if(!user||!ready)return;const ticket=++chatListTicket,actor=user.id;$('chat-list').innerHTML='<p class="muted">Buscando tus grupos…</p>';
  if(!capabilities.messages)await detectCapabilities();
  if(ticket!==chatListTicket||user?.id!==actor||view!=='chats')return;
  if(!capabilities.messages){$('chat-list').innerHTML=emptyHTML('El chat está por llegar.','Todavía falta habilitar el chat de grupos. Mientras tanto puedes consultar el punto de encuentro en tus planes.','reset');return;}
  try{const ids=await myPlanIds(actor);const rows=[];for(let start=0;;start+=100){let q=db.from('pinta_plans').select(fields()).order('starts_at',{ascending:false}).order('id');q=ids.length?q.or(`owner_id.eq.${actor},id.in.(${ids.join(',')})`):q.eq('owner_id',actor);const {data,error}=await boundedRead(q.range(start,start+99));if(error)throw error;rows.push(...data);if(data.length<100)break;}
    if(ticket!==chatListTicket||view!=='chats'||user?.id!==actor)return;
    $('chat-list').innerHTML=rows.length?rows.map(p=>`<button class="chat-item" data-chat="${esc(p.id)}"><span class="chat-thumb">${categoryOf(p).emoji}</span><span><strong>${esc(p.title)}</strong><small>${participants(p).length+1} personas · ${esc(localDate(p))}</small></span><span>${icon('arrow')}</span></button>`).join(''):emptyHTML('Los buenos planes empiezan hablando.','Cuando te sumes a un plan, su grupo aparecerá aquí.','reset');
  }catch(error){if(ticket===chatListTicket)$('chat-list').textContent=explain(error);}
}
async function openChat(id){
  if(!await ensureAdult({chat:id}))return;
  if(!capabilities.messages){notice('El chat de grupos todavía no está habilitado.');return;}
  stopChat();const ticket=++chatTicket;chatId=id;pendingMessage=null;$('chat-title').textContent='Cargando grupo…';$('messages').innerHTML='<p class="muted">Cargando mensajes…</p>';$('chat-error').textContent='';$('message').value='';$('send-message').disabled=true;openDialog('chat');
  try{const p=await readPlan(id);if(ticket!==chatTicket)return;if(!attends(p))throw Error('Únete al plan para entrar en su chat.');$('chat-title').textContent=p.title;await refreshChat(true);if(ticket===chatTicket){$('send-message').disabled=false;chatTimer=setInterval(()=>{if(!document.hidden&&$('chat').open)refreshChat();},6500);}}
  catch(error){if(ticket===chatTicket){$('messages').innerHTML='';$('chat-error').textContent=explain(error);}}
}
function stopChat(){clearInterval(chatTimer);chatTimer=null;++chatTicket;chatId=null;chatReadBusy=false;}
async function refreshChat(force=false){
  if(!chatId||!user||chatReadBusy)return;chatReadBusy=true;const ticket=chatTicket,id=chatId,actor=user.id;
  try{const p=await readPlan(id);if(ticket!==chatTicket)return;if(!attends(p)){stopChat();$('messages').innerHTML='';$('send-message').disabled=true;throw Error('Ya no participas en este plan.');}
    const {data,error}=await boundedRead(db.from('qp_messages').select('id,user_id,display_name,body,created_at').eq('plan_id',id).order('created_at',{ascending:false}).order('id',{ascending:false}).limit(100));if(error)throw error;if(ticket!==chatTicket||user?.id!==actor)return;
    const box=$('messages'),nearBottom=box.scrollHeight-box.scrollTop-box.clientHeight<80;
    const signature=data.map(m=>m.id).join(',');
    if(signature!==box.dataset.signature||force){box.dataset.signature=signature;box.innerHTML=data.length?`${data.length===100?'<p class="fine-print">Los últimos 100 mensajes del grupo.</p>':''}`+data.slice().reverse().map(m=>`<div class="message ${m.user_id===actor?'mine':''}"><strong>${esc(m.display_name)}</strong><p>${esc(m.body)}</p><time datetime="${esc(m.created_at)}">${esc(C.dateLabel(m.created_at))}</time></div>`).join(''):'<div class="empty-state"><h3>Rompe el hielo 👋</h3><p>Un «hola» es un buen comienzo.</p></div>';if(nearBottom||force)box.scrollTop=box.scrollHeight;}
    $('chat-error').textContent='';
  }catch(error){if(ticket===chatTicket||!chatId){$('chat-error').textContent=explain(error);}}finally{if(ticket===chatTicket)chatReadBusy=false;}
}
// Click routing works for dynamically rendered cards as well as static controls.
document.addEventListener('click',event=>{const b=event.target.closest('button');if(!b||b.disabled)return;
  if(b.hasAttribute('data-close'))b.closest('dialog').close();
  else if(b.hasAttribute('data-create'))createPlanDialog();
  else if(b.hasAttribute('data-profile'))openProfile();
  else if(b.hasAttribute('data-location')){ $('filter-country').value=countryFilter;$('filter-city').value=cityFilter;openDialog('location'); }
  else if(b.hasAttribute('data-reset')){goView('explore');}
  else if(b.dataset.view)goView(b.dataset.view);
  else if(b.dataset.plan)showPlan(b.dataset.plan);
  else if(b.dataset.save)toggleSave(b.dataset.save);
  else if(b.dataset.person)showPerson(b.dataset.person,b.dataset.name);
  else if(b.dataset.idea)createPlanDialog(b.dataset.idea);
  else if(b.dataset.chat)openChat(b.dataset.chat);
  else if(b.dataset.category){activity=b.dataset.category;loadPlans();}
  else if(b.dataset.date){dateFilter=b.dataset.date;loadPlans();}
});
$('filters').innerHTML=Object.entries(categories).map(([key,c])=>`<button class="category-tab" data-category="${key}" aria-pressed="${key==='Todos'}"><span class="category-icon" aria-hidden="true">${c.emoji}</span>${esc(c.label)}</button>`).join('');
$('search-form').onsubmit=e=>{e.preventDefault();clearTimeout(searchTimer);loadPlans();};
$('search').oninput=()=>{updateViewUI();clearTimeout(searchTimer);searchTimer=setTimeout(()=>loadPlans(),450);};
$('clear-search').onclick=()=>{$('search').value='';loadPlans();$('search').focus();};
$('zone').onchange=()=>loadPlans();$('reset-filters').onclick=()=>{resetFilters();loadPlans();};
$('seats-filter').onclick=()=>{onlySeats=!onlySeats;loadPlans();};$('free-filter').onclick=()=>{onlyFree=!onlyFree;loadPlans();};
$('reload').onclick=()=>ready?loadPlans():init();$('more').onclick=()=>loadPlans(true);
$('account').onclick=openProfile;$('login-tab').onclick=()=>openAuth('login',afterAuth);$('signup-tab').onclick=()=>openAuth('signup',afterAuth);$('forgot').onclick=()=>openAuth('reset',afterAuth);
$('join').onclick=()=>changeMembership();$('confirm-leave-button').onclick=()=>{$('confirm-leave').close();changeMembership(true);};
$('save-detail').onclick=()=>selectedId&&toggleSave(selectedId);$('share-plan').onclick=sharePlan;$('open-plan-chat').onclick=()=>selectedId&&openChat(selectedId);
$('description').oninput=()=>{$('description-count').textContent=`${$('description').value.length}/400`;};
$('chat').addEventListener('close',stopChat);
$('detail').addEventListener('close',()=>{++detailTicket;});
$('auth-form').onsubmit=async event=>{
  event.preventDefault();const button=$('auth-submit');if(button.disabled||!db)return;button.disabled=true;$('auth-message').textContent='';
  try{const email=$('auth-email').value.trim(),password=$('auth-password').value;
    if(authMode==='reset'){const {error}=await db.auth.resetPasswordForEmail(email,{redirectTo:SITE_URL});if(error)throw error;$('auth-message').textContent='Si el correo puede recibir la recuperación, te llegará un enlace. Revisa también spam.';return;}
    if(authMode==='update'){const {error}=await db.auth.updateUser({password});if(error)throw error;$('auth-password').value='';$('auth').close();notice('Contraseña actualizada.');return;}
    const display_name=$('auth-name').value.trim();if(authMode==='signup'&&!display_name)throw Error('Escribe tu nombre o apodo.');
    if(authMode==='signup'){if(!capabilities.v3||!capabilities.age)throw Error('El registro está en actualización. Inténtalo más tarde.');if(!C.isAdult($('auth-birthdate').value))throw Error('Debes tener al menos 18 años para crear una cuenta.');}
    const result=authMode==='signup'?await db.auth.signUp({email,password,options:{data:{display_name,birth_date:$('auth-birthdate').value},emailRedirectTo:SITE_URL}}):await db.auth.signInWithPassword({email,password});
    if(result.error)throw result.error;$('auth-password').value='';
    if(!result.data.session){$('auth-message').textContent='Revisa tu correo para confirmar la cuenta. Si ya tienes una, entra o recupera tu contraseña.';return;}
    user=result.data.user;authUI();const next=afterAuth;afterAuth=null;$('auth').close();notice('¡Ya estás en Que Pinta!');await detectCapabilities();await loadPlans();await resumeAfterAuth(next);
  }catch(error){$('auth-message').textContent=explain(error);}finally{button.disabled=false;}
};
$('signout').onclick=async()=>{
  $('signout').disabled=true;$('profile-error').textContent='';
  try{const {error}=await db.auth.signOut({scope:'local'});if(error)throw error;user=null;view='explore';stopChat();publicProfiles.clear();for(const d of document.querySelectorAll('dialog[open]'))d.close();authUI();await loadPlans();notice('Sesión cerrada en este dispositivo.');}
  catch(error){$('profile-error').textContent=explain(error);}finally{$('signout').disabled=false;}
};
$('profile-form').onsubmit=async event=>{
  event.preventDefault();if(!user||$('profile-save').disabled)return;$('profile-save').disabled=true;$('profile-error').textContent='';
  try{const display_name=$('profile-name').value.trim(),bio=$('profile-bio').value.trim(),rawPhoto=$('profile-photo').value.trim(),avatar_url=C.safePhoto(rawPhoto),interests=[...document.querySelectorAll('input[name=interest]:checked')].map(i=>i.value);if(!display_name)throw Error('Escribe tu nombre.');if(rawPhoto&&!avatar_url)throw Error('La foto debe usar un enlace HTTPS válido.');
    const instagram_url=C.socialURL($('profile-instagram').value,'instagram'),facebook_url=C.socialURL($('profile-facebook').value,'facebook'),show_socials=$('show-socials').checked;
    if($('profile-instagram').value.trim()&&!instagram_url)throw Error('Escribe un usuario de Instagram o un enlace HTTPS a su perfil.');
    if($('profile-facebook').value.trim()&&!facebook_url)throw Error('Escribe un enlace HTTPS a un perfil de Facebook.');
    const values={display_name,bio,avatar_url,interests,instagram_url,facebook_url,show_socials};const {data,error}=await db.auth.updateUser({data:values});if(error)throw error;user=data.user;authUI();$('profile-avatar').innerHTML=profilePhoto(avatar_url);
    if(capabilities.profiles){const {error:profileError}=await db.from('qp_profiles').upsert({id:user.id,display_name,bio,avatar_url,interests,...(capabilities.v3?{instagram_url:show_socials?instagram_url:'',facebook_url:show_socials?facebook_url:''}:{})},{onConflict:'id'});if(profileError){$('profile-error').textContent='Se guardó en tu cuenta, pero no se pudo actualizar el perfil público. Vuelve a guardar para reintentarlo.';return;}publicProfiles.set(user.id,{id:user.id,...values});}
    notice('Tu perfil quedó guardado.');$('profile').close();await loadPlans();
  }catch(error){$('profile-error').textContent=explain(error);}finally{$('profile-save').disabled=false;}
};
$('form').onsubmit=async event=>{
  event.preventDefault();const button=$('create-submit');if(button.disabled)return;if(!await ensureAdult({create:true}))return;button.disabled=true;$('create-error').textContent='';
  try{
    const qp_timezone=$('plan-timezone').value,starts_at=C.inputToISO($('date').value,qp_timezone);
    if(new Date(starts_at)<=new Date())throw Error('Elige una fecha futura.');
    const capacity=Number($('capacity').value);if(!Number.isInteger(capacity)||capacity<2||capacity>30)throw Error('Elige entre 2 y 30 plazas.');
    const qp_country_code=$('plan-country').value,qp_city=$('plan-city').value.trim();
    if(!PintaGeo[qp_country_code]||!qp_city||!PintaGeo[qp_country_code].some(z=>z[0]===qp_timezone))throw Error('Revisa el país, la ciudad y la zona horaria.');
    const qp_cost=$('cost').value!==''?Number($('cost').value):null;
    if(qp_cost!==null&&(!Number.isFinite(qp_cost)||qp_cost<0||qp_cost>100000))throw Error('El costo debe estar entre 0 y 100000.');
    if(($('latitude').value||$('longitude').value)&&(!meetingPin||Number($('latitude').value)!==meetingPin.lat||Number($('longitude').value)!==meetingPin.lng))throw Error('Aplica las coordenadas antes de publicar, o borra ambos campos.');
    const p={owner_id:user.id,owner_name:$('host-name').value.trim(),title:$('title').value.trim(),category:$('category').value,neighborhood:$('neighborhood').value.trim(),meeting_point:$('place').value.trim(),starts_at,capacity,description:$('description').value.trim(),qp_country_code,qp_city,qp_timezone,qp_latitude:meetingPin?.lat??null,qp_longitude:meetingPin?.lng??null,qp_cost,qp_currency:$('currency').value};
    if(!p.owner_name||!p.title||!p.meeting_point||!p.description||!p.neighborhood)throw Error('Completa los campos del encuentro.');
    const {data,error}=await db.from('pinta_plans').insert(p).select('id').single();if(error)throw error;
    $('create').close();event.target.reset();$('plan-country').value='';meetingPin=null;$('description-count').textContent='0/400';notice('¡Tu plan está publicado!');celebrate();
    countryFilter=qp_country_code;cityFilter=qp_city;saveLocation();view='mine';resetFilters();await loadPlans();await showPlan(String(data.id));
  }catch(error){$('create-error').textContent=explain(error);}finally{button.disabled=false;}
};

$('cancel-plan').onclick=()=>{$('cancel-title').textContent=$('detail-title').textContent;$('cancel-error').textContent='';openDialog('confirm-cancel');};
$('confirm-delete').onclick=async()=>{
  const button=$('confirm-delete');if(button.disabled||!user||!selectedId)return;const id=selectedId,actor=user.id;button.disabled=true;$('cancel-error').textContent='';
  try{const {data,error}=await db.from('pinta_plans').delete().eq('id',id).eq('owner_id',actor).select('id');if(error)throw error;if(!data.length)throw Error('El plan ya no existe o tu sesión cambió.');$('confirm-cancel').close();$('detail').close();selectedId=null;selectedPlan=null;if(saved.has(id)){saved.delete(id);try{localStorage.setItem('qp.saved.v2',JSON.stringify([...saved]));}catch{}}notice('Plan cancelado.');await loadPlans();}
  catch(error){$('cancel-error').textContent=explain(error);}finally{button.disabled=false;}
};
$('chat-form').onsubmit=async event=>{
  event.preventDefault();if(!await ensureAdult())return;const button=$('send-message');if(button.disabled||!chatId||!user)return;const body=$('message').value.trim();if(!body)return;
  const id=chatId,actor=user.id,ticket=chatTicket;button.disabled=true;$('chat-error').textContent='';
  try{if(!pendingMessage||pendingMessage.body!==body||pendingMessage.plan_id!==id||pendingMessage.user_id!==actor)pendingMessage={id:crypto.randomUUID(),plan_id:id,user_id:actor,display_name:nameOfUser(),body};
    const {error}=await db.from('qp_messages').insert(pendingMessage);if(error&&error.code!=='23505')throw error;
    if(chatId===id&&user?.id===actor&&ticket===chatTicket){$('message').value='';pendingMessage=null;await refreshChat(true);}
  }catch(error){if(ticket===chatTicket)$('chat-error').textContent=explain(error);}finally{if(ticket===chatTicket)button.disabled=false;}
};
async function init(){
  if(initializing)return;initializing=true;$('reload').disabled=true;setLoadError('');
  try{
    if(!window.supabase){$('reload').onclick=()=>location.reload();throw Error('No se pudo cargar la conexión. Revisa internet y toca Actualizar para recargar.');}
    if(!db){db=window.supabase.createClient(PROJECT_URL,PUBLIC_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
      db.auth.onAuthStateChange((event,session)=>{const before=user?.id;user=session?.user||null;if(before!==user?.id)adultUserId=null;authUI();
        if(event==='SIGNED_OUT'){view='explore';stopChat();publicProfiles.clear();$('messages').innerHTML='';$('chat-list').innerHTML='';for(const d of document.querySelectorAll('dialog[open]'))d.close();updateViewUI();}
        // Auth callbacks must return before making another async auth request.
        if(event==='PASSWORD_RECOVERY')setTimeout(()=>{ready=true;openAuth('update');},0);
        if(ready&&before!==user?.id)setTimeout(()=>loadPlans(),0);
      });
    }
    // Public discovery should still work if a stored login has expired.
    try{const {data,error}=await boundedRead(db.auth.getSession(),10000);if(!error)user=data.session?.user||null;else notice('Revisa tu sesión para unirte a un plan.');}catch{user=null;notice('Puedes explorar. Vuelve a entrar para participar.');}
    ready=true;authUI();await detectCapabilities();await loadPlans();
    const id=new URL(location.href).searchParams.get('plan');if(id&&/^[a-zA-Z0-9_-]{1,80}$/.test(id)&&!openedShared&&!$('auth').open){openedShared=true;await showPlan(id);}
  }catch(error){setLoadError(explain(error));$('plans').innerHTML='';$('count').textContent='Sin conexión';$('plans').setAttribute('aria-busy','false');}
  finally{initializing=false;$('reload').disabled=false;}
}
window.addEventListener('online',()=>ready?loadPlans():init());
window.addEventListener('offline',()=>notice('Estás sin conexión. Vuelve a conectarte para actualizar los planes.'));
window.addEventListener('storage',event=>{if(event.key==='qp.saved.v2'){try{const list=JSON.parse(event.newValue||'[]');if(Array.isArray(list)){saved=new Set(list.filter(id=>typeof id==='string'&&/^[a-zA-Z0-9_-]{1,80}$/.test(id)));if(view==='saved')loadPlans();else render();}}catch{}}});
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&ready&&!document.querySelector('dialog[open]'))loadPlans();});
// Back closes an open sheet before leaving on Android/Capacitor.
if(window.Capacitor?.isNativePlatform?.()&&window.Capacitor.registerPlugin){const nativeApp=window.Capacitor.registerPlugin('App');nativeApp.addListener('backButton',()=>{const dialogs=[...document.querySelectorAll('dialog[open]')];if(dialogs.length)dialogs[dialogs.length-1].close();else if(view!=='explore')goView('explore');else nativeApp.exitApp();}).catch(()=>{});}
function countryOptions(all=false){return (all?'<option value="">Todos los países</option>':'<option value="" disabled>Elige un país</option>')+Object.keys(PintaGeo).sort((a,b)=>countryName(a).localeCompare(countryName(b),'es')).map(code=>`<option value="${code}">${esc(countryName(code))}</option>`).join('');}
function updateLocationLabels(){document.querySelectorAll('[data-location-label]').forEach(el=>el.textContent=[cityFilter,countryFilter?countryName(countryFilter):'Todos los países'].filter(Boolean).join(' · '));}
function saveLocation(){try{localStorage.setItem('qp.location.v3',JSON.stringify({country:countryFilter,city:cityFilter}));}catch{}updateLocationLabels();}
function populateTimezones(){
  const country=$('plan-country').value,zones=PintaGeo[country]||PintaGeo.UY;
  $('plan-timezone').innerHTML=zones.map(([z])=>`<option value="${esc(z)}">${esc(z.split('/').slice(1).join(' / ').replaceAll('_',' '))}</option>`).join('');
  $('plan-timezone').value=zones[0][0];$('date').min=C.inputDate(new Date(Date.now()+60000),zones[0][0]);
  const currencies={UY:'UYU',AR:'ARS',BR:'BRL',CL:'CLP',CO:'COP',PE:'PEN',MX:'MXN',CU:'CUP',DO:'DOP',BO:'BOB',PY:'PYG',VE:'VES',CR:'CRC',GT:'GTQ',HN:'HNL',NI:'NIO',CA:'CAD',GB:'GBP',JP:'JPY',CN:'CNY',ES:'EUR',PT:'EUR',FR:'EUR',DE:'EUR',IT:'EUR'};
  $('currency').value=currencies[country]||'USD';
}
function mapCenter(){return (PintaGeo[$('plan-country').value]||PintaGeo.UY).find(z=>z[0]===$('plan-timezone').value)?.slice(1)||(PintaGeo[$('plan-country').value]||PintaGeo.UY)[0].slice(1);}
function setMeetingPin(lat,lng){
  if(!C.validCoordinates(lat,lng))return;
  meetingPin={lat:Number(lat.toFixed(6)),lng:Number(lng.toFixed(6))};
  $('latitude').value=meetingPin.lat;$('longitude').value=meetingPin.lng;
  $('map-status').textContent='Punto marcado. Comprueba que coincide con la ciudad y la dirección del encuentro.';
}
function initCreateMap(){
  createMap?.remove();createMap=PintaMaps.create($('create-map'),meetingPin?[meetingPin.lat,meetingPin.lng]:mapCenter(),setMeetingPin,text=>$('map-status').textContent=text);
  if(meetingPin)createMap?.select(meetingPin.lat,meetingPin.lng);
}
function showMeetingMap(plan){
  detailMap?.remove();detailMap=null;
  const valid=C.validCoordinates(plan.qp_latitude,plan.qp_longitude);
  $('detail-map-section').hidden=!valid;$('directions').hidden=false;$('directions').href=C.directionsURL(plan);$('detail-map-status').textContent='';
  if(valid){detailMap=PintaMaps.create($('detail-map'),[plan.qp_latitude,plan.qp_longitude],null,text=>$('detail-map-status').textContent=text);detailMap?.select(plan.qp_latitude,plan.qp_longitude);detailMap?.center(plan.qp_latitude,plan.qp_longitude,16);}
}
function clearMeetingPin(){meetingPin=null;createMap?.clear();$('latitude').value='';$('longitude').value='';$('map-status').textContent='El punto que elijas será público.';}
async function searchMap(){
  const query=$('map-query').value.trim();if(query.length<3){$('map-status').textContent='Escribe al menos 3 caracteres para buscar.';return;}
  const ticket=++mapSearchTicket;$('map-search-button').disabled=true;$('map-status').textContent='Buscando lugares…';$('map-results').innerHTML='';
  try{
    const rows=await PintaMaps.search(query,$('plan-country').value,$('plan-city').value.trim(),mapCenter());
    if(ticket!==mapSearchTicket||!$('create').open)return;
    $('map-status').textContent=rows.length?'Elige un resultado y ajusta el pin si hace falta.':'No hay resultados en este país. Intenta otra búsqueda o marca el mapa.';
    for(const result of rows){const b=document.createElement('button');b.type='button';b.textContent=result.name;b.onclick=()=>{setMeetingPin(result.lat,result.lng);createMap?.select(result.lat,result.lng);createMap?.center(result.lat,result.lng);$('place').value=result.name.slice(0,150);$('map-results').innerHTML='';};$('map-results').appendChild(b);}
  }catch(error){if(ticket===mapSearchTicket)$('map-status').textContent=error.name==='TimeoutError'?'La búsqueda tardó demasiado. Puedes marcar el mapa.':error.message;}
  finally{if(ticket===mapSearchTicket)$('map-search-button').disabled=false;}
}
async function ensureAdult(next=null){
  if(!user){openAuth('login',next);return false;}
  if(!capabilities.v3||!capabilities.age){notice('La nueva versión necesita activar sus funciones antes de participar. Los planes siguen disponibles.');return false;}
  const actor=user.id;if(adultUserId===actor)return true;
  try{const {data,error}=await boundedRead(db.from('qp_age_declarations').select('user_id').eq('user_id',actor).maybeSingle());if(error)throw error;if(user?.id!==actor)return false;if(data){adultUserId=actor;return true;}}
  catch(error){notice(explain(error));return false;}
  afterAge=next;$('age-error').textContent='';openDialog('age');return false;
}
function animateCards(){
  cardObserver?.disconnect();
  if(typeof IntersectionObserver==='undefined'||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  cardObserver=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting){entry.target.classList.remove('reveal-pending');cardObserver.unobserve(entry.target);}},{threshold:.07});
  document.querySelectorAll('.plan-card').forEach(card=>{card.classList.add('reveal-pending');cardObserver.observe(card);});
}
function celebrate(){
  if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  const layer=$('celebration');layer.replaceChildren();
  for(let i=0;i<18;i++){const part=document.createElement('i');part.style.setProperty('--x',(Math.random()*100)+'vw');part.style.setProperty('--delay',(Math.random()*.3)+'s');part.style.background=['#7c3aed','#ffad71','#d3b6ff'][i%3];layer.append(part);}
  setTimeout(()=>layer.replaceChildren(),1800);
}
$('plan-country').innerHTML=countryOptions();$('filter-country').innerHTML=countryOptions(true);$('plan-country').value='';
$('currency').innerHTML=(Intl.supportedValuesOf?Intl.supportedValuesOf('currency'):['USD','EUR','UYU','ARS','BRL','CLP','COP','MXN']).map(c=>`<option value="${c}">${c}</option>`).join('');
$('location-form').onsubmit=e=>{e.preventDefault();countryFilter=$('filter-country').value;cityFilter=$('filter-city').value.trim();saveLocation();$('location').close();resetFilters();loadPlans();};
$('filter-country').onchange=()=>{$('filter-city').value='';};
$('plan-country').onchange=()=>{++mapSearchTicket;$('map-search-button').disabled=false;$('plan-city').value='';$('neighborhood').value='';$('place').value='';$('map-query').value='';$('map-results').replaceChildren();$('date').value='';populateTimezones();clearMeetingPin();initCreateMap();};
$('plan-city').onchange=()=>{++mapSearchTicket;$('map-search-button').disabled=false;clearMeetingPin();$('map-results').replaceChildren();};
$('plan-timezone').onchange=()=>{clearMeetingPin();initCreateMap();$('date').min=C.inputDate(new Date(Date.now()+60000),$('plan-timezone').value);};
$('map-search-button').onclick=searchMap;$('map-query').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();searchMap();}};
$('remove-pin').onclick=clearMeetingPin;
$('apply-coordinates').onclick=()=>{const lat=Number($('latitude').value),lng=Number($('longitude').value);if(!$('latitude').value||!$('longitude').value||!C.validCoordinates(lat,lng)){$('map-status').textContent='Introduce una latitud entre −85 y 85 y una longitud entre −180 y 180.';return;}setMeetingPin(lat,lng);createMap?.select(lat,lng);createMap?.center(lat,lng);};
$('locate').onclick=async()=>{const ticket=mapSearchTicket;$('locate').disabled=true;$('map-status').textContent='Esperando tu ubicación…';try{const position=await PintaMaps.locate();if(!$('create').open||ticket!==mapSearchTicket)return;const {latitude:lat,longitude:lng}=position.coords;setMeetingPin(lat,lng);createMap?.select(lat,lng);createMap?.center(lat,lng);}catch{$('map-status').textContent='No se pudo obtener tu ubicación. Puedes buscar un lugar o tocar el mapa.';}finally{$('locate').disabled=false;}};
$('age-form').onsubmit=async e=>{
  e.preventDefault();if(!user||$('age-submit').disabled)return;$('age-error').textContent='';
  const birth_date=$('age-birthdate').value;if(!C.isAdult(birth_date)){$('age-error').textContent='Debes tener al menos 18 años para participar.';return;}
  $('age-submit').disabled=true;const actor=user.id;
  try{const {error}=await db.from('qp_age_declarations').insert({user_id:actor,birth_date});if(error)throw error;if(user?.id!==actor)return;adultUserId=actor;$('age').close();$('age-form').reset();const next=afterAge;afterAge=null;notice('Declaración guardada de forma privada.');await resumeAfterAuth(next);}catch(error){$('age-error').textContent=explain(error);}finally{$('age-submit').disabled=false;}
};
$('create').addEventListener('close',()=>{++mapSearchTicket;createMap?.remove();createMap=null;$('map-search-button').disabled=false;});
$('detail').addEventListener('close',()=>{detailMap?.remove();detailMap=null;});
for(const id of ['auth-birthdate','age-birthdate'])$(id).max=C.dateKey(new Date(),'UTC');
document.addEventListener('click',e=>{const b=e.target.closest('.save-button,.category-tab,.bottom-nav button');if(b&&!matchMedia('(prefers-reduced-motion: reduce)').matches)b.animate([{transform:'scale(1)'},{transform:'scale(.92)'},{transform:'scale(1)'}],{duration:260});});
updateLocationLabels();

paintIcons();authUI();updateViewUI();init();
